package com.example.data

import com.google.firebase.Timestamp

data class Branch(
    val id: String = "",
    val ad: String = "",
    val slug: String = "",
    val apiKey: String = "",
    val lat: Double? = null,
    val lng: Double? = null,
    val radius: Double? = 150.0,
    val locationCheckEnabled: Boolean = true,
    val createdAt: Timestamp? = null
)

data class User(
    val uid: String = "",
    val kullaniciAdi: String = "",
    val rol: String = "", // admin, mudur, garson
    val branchId: String = "",
    val ad: String = "",
    val fcmToken: String = "",
    val createdAt: Timestamp? = null
)

data class Table(
    val id: String = "",
    val branchId: String = "",
    val masaNo: String = "",
    val createdAt: Timestamp? = null
)

data class CallOrderItem(
    val urunAdi: String = "",
    val adet: Long = 1,
    val notOrijinal: String? = null,
    val notTr: String? = null,
    val ceviri_hata: Boolean? = null
)

data class Call(
    val id: String = "",
    val branchId: String = "",
    val masaNo: String = "",
    val tip: String = "", // "garson", "hesap", "siparis"
    val durum: String = "", // "bekliyor", "onaylandi", "iptal"
    val onaylayanUid: String = "",
    val onaylayanAd: String = "",
    val createdAt: Timestamp? = null,
    val onaylandiAt: Timestamp? = null,
    val items: List<CallOrderItem> = emptyList(),
    val notDili: String? = null,
    val iptalNedeni: String = "",
    val iptalEdenAd: String = "",
    val iptalAt: Timestamp? = null
)

data class Shift(
    val id: String = "",
    val branchId: String = "",
    val garsonUid: String = "",
    val garsonAd: String = "",
    val baslangic: Timestamp? = null,
    val bitis: Timestamp? = null,
    val durum: String = "", // "acik", "kapali"
    val molada: Boolean = false,
    val molaBaslangic: Timestamp? = null
)

data class ShiftBreak(
    val id: String = "",
    val baslangic: Timestamp? = null,
    val bitis: Timestamp? = null
)

data class ShiftWithBreaks(
    val shift: Shift,
    val breaks: List<ShiftBreak> = emptyList()
)

data class AnalyticsProductItem(
    val urunAd: String = "",
    val kategori: String = "",
    val tiklamaAdedi: Int = 0
)

data class AnalyticsTableItem(
    val masaAd: String = "",
    val goruntulenmeAdedi: Int = 0
)

data class AnalyticsResponse(
    val toplamGoruntulenme: Int = 0,
    val tekilZiyaretci: Int = 0,
    val toplamTiklama: Int = 0,
    val enCok: List<AnalyticsProductItem> = emptyList(),
    val enAz: List<AnalyticsProductItem> = emptyList(),
    val masalar: List<AnalyticsTableItem> = emptyList()
)
