package com.example.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.utils.FormatUtils
import com.example.utils.SoundSettingsManager
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

class CallsForegroundService : Service() {

    private var listenerRegistration: ListenerRegistration? = null
    private val serviceStartTime = System.currentTimeMillis()
    private val activeNotifications = mutableSetOf<String>()

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val prefs = getSharedPreferences("qr_servis_prefs", Context.MODE_PRIVATE)
        val branchId = prefs.getString("branch_id", "") ?: ""

        // Show persistent notification to keep service alive
        val mainPendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).apply {
                setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val persistentNotification = NotificationCompat.Builder(this, CHANNEL_STATUS_ID)
            .setContentTitle("QR Servis Çalışıyor")
            .setContentText("Masalardan gelen çağrılar dinleniyor.")
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentIntent(mainPendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()

        // Start as foreground service
        startForeground(NOTIFICATION_FOREGROUND_ID, persistentNotification)

        if (branchId.isNotEmpty()) {
            startListening(branchId)
        } else {
            stopSelf()
        }

        return START_STICKY
    }

    private fun startListening(branchId: String) {
        listenerRegistration?.remove()

        val db = FirebaseFirestore.getInstance()
        listenerRegistration = db.collection("calls")
            .whereEqualTo("branchId", branchId)
            .addSnapshotListener { snapshots, error ->
                if (error != null || snapshots == null) return@addSnapshotListener

                for (dc in snapshots.documentChanges) {
                    val doc = dc.document
                    val callId = doc.id
                    val masaNo = doc.getString("masaNo") ?: ""
                    val tip = doc.getString("tip") ?: ""
                    val durum = doc.getString("durum") ?: ""
                    val createdAt = doc.getTimestamp("createdAt")

                    @Suppress("UNCHECKED_CAST")
                    val itemsList = doc.get("items") as? List<Map<String, Any>>
                    val itemCount = itemsList?.size ?: 0

                    val isNew = if (createdAt != null) {
                        createdAt.toDate().time >= serviceStartTime
                    } else {
                        false
                    }

                    when (dc.type) {
                        DocumentChange.Type.ADDED -> {
                            if (durum == "bekliyor" && isNew) {
                                showCallNotification(callId, masaNo, tip, itemCount)
                            }
                        }
                        DocumentChange.Type.MODIFIED -> {
                            if (durum == "onaylandi") {
                                cancelCallNotification(callId)
                            } else if (durum == "bekliyor" && !activeNotifications.contains(callId) && isNew) {
                                showCallNotification(callId, masaNo, tip, itemCount)
                            }
                        }
                        DocumentChange.Type.REMOVED -> {
                            cancelCallNotification(callId)
                        }
                    }
                }
            }
    }

    private fun showCallNotification(callId: String, masaNo: String, tip: String, itemCount: Int = 0) {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            callId.hashCode(),
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val formattedMasa = FormatUtils.formatMasaTitle(masaNo)
        val (title, message) = when (tip) {
            "siparis" -> "$formattedMasa — Yeni Sipariş" to "$itemCount ürün"
            "hesap" -> formattedMasa to "Hesap istiyor"
            else -> formattedMasa to "Garson çağırıyor"
        }

        val notification = NotificationCompat.Builder(this, CHANNEL_CALL_ID)
            .setContentTitle(title)
            .setContentText(message)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setContentIntent(pendingIntent)
            .setSound(null)
            .setVibrate(longArrayOf(0L))
            .setAutoCancel(true)
            .build()

        notificationManager.notify(callId.hashCode(), notification)
        activeNotifications.add(callId)

        // Play custom notification sound & vibration according to user settings
        SoundSettingsManager.playSoundAndVibrateForCallType(this, tip)
    }

    private fun cancelCallNotification(callId: String) {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.cancel(callId.hashCode())
        activeNotifications.remove(callId)
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            // Status channel for persistent notification
            val statusChannel = NotificationChannel(
                CHANNEL_STATUS_ID,
                "QR Servis Durumu",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Uygulamanın arka planda çalıştığını belirtir."
            }
            notificationManager.createNotificationChannel(statusChannel)

            // Call channel for active notifications (silent sound so MediaPlayer plays custom sound)
            val callChannel = NotificationChannel(
                CHANNEL_CALL_ID,
                "Masalardan Çağrılar",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Yeni garson veya hesap çağrılarını bildirir."
                enableLights(true)
                setSound(null, null)
                enableVibration(false)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            notificationManager.createNotificationChannel(callChannel)
        }
    }

    override fun onDestroy() {
        listenerRegistration?.remove()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val CHANNEL_STATUS_ID = "com.qrmenuofficial.servis.durum_kanali"
        const val CHANNEL_CALL_ID = "com.qrmenuofficial.servis.cagri_kanali"
        const val NOTIFICATION_FOREGROUND_ID = 9991
    }
}
