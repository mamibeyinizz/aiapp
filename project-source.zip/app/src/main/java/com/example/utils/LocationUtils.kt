package com.example.utils

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Build
import androidx.core.content.ContextCompat

object LocationUtils {

    fun hasLocationPermission(context: Context): Boolean {
        val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        return fine || coarse
    }

    fun isLocationEnabled(context: Context): Boolean {
        val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return false
        val gpsEnabled = try { locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) } catch (e: Exception) { false }
        val netEnabled = try { locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER) } catch (e: Exception) { false }
        return gpsEnabled || netEnabled
    }

    fun getCurrentLocation(
        context: Context,
        onLocationObtained: (Location) -> Unit,
        onError: (String) -> Unit
    ) {
        if (!hasLocationPermission(context)) {
            onError("PERMISSION_DENIED")
            return
        }

        val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        if (locationManager == null) {
            onError("Konum servisi kullanılamıyor.")
            return
        }

        if (!isLocationEnabled(context)) {
            onError("LOCATION_DISABLED")
            return
        }

        var lastKnown: Location? = null
        try {
            val gpsLoc = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            val netLoc = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            lastKnown = if (gpsLoc != null && netLoc != null) {
                if (gpsLoc.time > netLoc.time) gpsLoc else netLoc
            } else gpsLoc ?: netLoc
        } catch (e: SecurityException) {
            onError("PERMISSION_DENIED")
            return
        } catch (e: Exception) {}

        if (lastKnown != null && (System.currentTimeMillis() - lastKnown.time) < 2 * 60 * 1000) {
            onLocationObtained(lastKnown)
            return
        }

        val provider = when {
            try { locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) } catch (e: Exception) { false } -> LocationManager.GPS_PROVIDER
            try { locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER) } catch (e: Exception) { false } -> LocationManager.NETWORK_PROVIDER
            else -> null
        }

        if (provider == null) {
            if (lastKnown != null) {
                onLocationObtained(lastKnown)
            } else {
                onError("LOCATION_DISABLED")
            }
            return
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                locationManager.getCurrentLocation(
                    provider,
                    null,
                    context.mainExecutor
                ) { location ->
                    if (location != null) {
                        onLocationObtained(location)
                    } else if (lastKnown != null) {
                        onLocationObtained(lastKnown)
                    } else {
                        onError("Konum alınamadı. GPS'inizin açık olduğunu kontrol edin.")
                    }
                }
            } else {
                locationManager.requestSingleUpdate(
                    provider,
                    object : android.location.LocationListener {
                        override fun onLocationChanged(location: Location) {
                            onLocationObtained(location)
                        }
                        override fun onStatusChanged(p: String?, s: Int, e: android.os.Bundle?) {}
                        override fun onProviderEnabled(p: String) {}
                        override fun onProviderDisabled(p: String) {}
                    },
                    null
                )
            }
        } catch (e: SecurityException) {
            onError("PERMISSION_DENIED")
        } catch (e: Exception) {
            if (lastKnown != null) {
                onLocationObtained(lastKnown)
            } else {
                onError(ErrorUtils.parseError(e, "Konum alınamadı, lütfen tekrar deneyin."))
            }
        }
    }

    fun calculateDistanceMeters(lat1: Double, lng1: Double, lat2: Double, lng2: Double): Float {
        val results = FloatArray(1)
        Location.distanceBetween(lat1, lng1, lat2, lng2, results)
        return results[0]
    }
}
