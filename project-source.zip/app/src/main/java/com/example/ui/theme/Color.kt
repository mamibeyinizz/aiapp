package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBg = Color(0xFF0B0D12)
val DarkSurface = Color(0xFF151821)
val DarkSurfaceSecondary = Color(0xFF1C202B)

val TealPrimary = Color(0xFF4FD1C5)
val TealAccent = Color(0xFF38B2AC)

// Compatibility aliases for Gold tokens
val GoldPrimary = TealPrimary
val GoldAccent = TealAccent

val TextPrimary = Color(0xFFF2F3F5)
val TextSecondary = Color(0xFF8A8F9C)

val StatusTeal = Color(0xFF4FD1C5)
val StatusGreen = Color(0xFF34D399)
val StatusRed = Color(0xFFF87171)
val StatusAmber = Color(0xFFFBBF24) // ONLY for break/mola state

val ErrorColor = StatusRed
val BorderColor = Color(0x14FFFFFF)
