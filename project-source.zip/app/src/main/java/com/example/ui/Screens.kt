package com.example.ui

import com.example.viewmodel.WORDPRESS_BASE_URL
import com.example.utils.FormatUtils

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.zIndex
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.*
import com.example.utils.LocationUtils
import com.example.ui.theme.*
import com.example.viewmodel.ApprovedCallInfo
import com.example.viewmodel.AppViewModel
import com.example.viewmodel.LoginState
import com.google.firebase.Timestamp
import kotlinx.coroutines.delay

// --- UTILS ---
fun formatElapsedTime(timestamp: Timestamp?): String {
    if (timestamp == null) return "az önce"
    val diffMs = System.currentTimeMillis() - timestamp.toDate().time
    val diffSec = diffMs / 1000
    if (diffSec < 0) return "az önce"
    if (diffSec < 60) return "az önce"
    val diffMin = diffSec / 60
    if (diffMin < 60) return "$diffMin dk önce"
    val diffHrs = diffMin / 60
    if (diffHrs < 24) return "$diffHrs saat önce"
    val diffDays = diffHrs / 24
    return "$diffDays gün önce"
}

fun formatPendingCallTime(createdAt: Timestamp?, nowMs: Long): String {
    if (createdAt == null) return "az önce çağrıldı"
    val diffMs = nowMs - createdAt.toDate().time
    val diffSec = diffMs / 1000
    if (diffSec < 60) {
        return if (diffSec <= 0) "az önce çağrıldı" else "$diffSec sn önce çağrıldı"
    }
    val diffMin = diffSec / 60
    if (diffMin < 60) return "$diffMin dk önce çağrıldı"
    val diffHrs = diffMin / 60
    if (diffHrs < 24) return "$diffHrs saat önce çağrıldı"
    return "${diffHrs / 24} gün önce çağrıldı"
}

// --- SHARED COMPONENTS ---
@Composable
fun LiveApprovalBanner(info: ApprovedCallInfo?, onDismiss: () -> Unit) {
    AnimatedVisibility(
        visible = info != null,
        enter = fadeIn() + slideInVertically(initialOffsetY = { -it }),
        exit = fadeOut() + slideOutVertically(targetOffsetY = { -it })
    ) {
        if (info != null) {
            LaunchedEffect(info.timestamp) {
                delay(3000)
                onDismiss()
            }
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .testTag("live_approval_banner"),
                colors = CardDefaults.cardColors(containerColor = TealPrimary),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = DarkBg,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${FormatUtils.formatMasaTitle(info.masaNo)} Onaylandı",
                            color = DarkBg,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Text(
                            text = "${info.onaylayanAd} tarafından onaylandı.",
                            color = DarkBg.copy(alpha = 0.8f),
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ExitConfirmDialog(
    onDismiss: () -> Unit,
    onConfirmExit: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        title = {
            Text(
                text = "Çıkış",
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Text(
                text = "Uygulamadan çıkmak istediğinize emin misiniz?",
                color = TextSecondary,
                fontSize = 14.sp
            )
        },
        confirmButton = {
            Button(
                onClick = onConfirmExit,
                colors = ButtonDefaults.buttonColors(
                    containerColor = ErrorColor,
                    contentColor = Color.White
                ),
                modifier = Modifier.testTag("confirm_exit_app_button")
            ) {
                Text("Çık", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_exit_app_button")
            ) {
                Text("İptal", color = TextSecondary)
            }
        }
    )
}

// --- 5.1 LOGIN SCREEN ---
private data class GoldParticle(
    val xRatio: Float,
    val initialYRatio: Float,
    val speed: Float,
    val radiusDp: Float,
    val alpha: Float,
    val swayPhase: Float
)

private val loginGoldParticles = listOf(
    GoldParticle(0.08f, 0.05f, 1.0f, 2.5f, 0.25f, 0.1f),
    GoldParticle(0.18f, 0.42f, 1.3f, 3.2f, 0.35f, 0.8f),
    GoldParticle(0.25f, 0.85f, 0.8f, 2.0f, 0.18f, 2.1f),
    GoldParticle(0.32f, 0.15f, 1.1f, 3.8f, 0.38f, 1.4f),
    GoldParticle(0.41f, 0.65f, 0.9f, 2.2f, 0.22f, 3.2f),
    GoldParticle(0.48f, 0.28f, 1.4f, 2.8f, 0.30f, 0.5f),
    GoldParticle(0.55f, 0.90f, 0.7f, 4.0f, 0.40f, 1.9f),
    GoldParticle(0.62f, 0.48f, 1.2f, 2.1f, 0.20f, 2.7f),
    GoldParticle(0.70f, 0.10f, 1.0f, 3.5f, 0.32f, 0.3f),
    GoldParticle(0.78f, 0.75f, 1.3f, 2.6f, 0.28f, 1.1f),
    GoldParticle(0.85f, 0.35f, 0.85f, 3.0f, 0.24f, 2.4f),
    GoldParticle(0.92f, 0.58f, 1.15f, 2.3f, 0.22f, 0.9f),
    GoldParticle(0.12f, 0.72f, 1.05f, 3.6f, 0.36f, 1.7f),
    GoldParticle(0.38f, 0.93f, 1.25f, 2.4f, 0.19f, 2.9f),
    GoldParticle(0.58f, 0.08f, 0.95f, 3.1f, 0.33f, 0.6f),
    GoldParticle(0.67f, 0.82f, 1.35f, 2.7f, 0.27f, 1.2f),
    GoldParticle(0.76f, 0.22f, 0.75f, 3.9f, 0.39f, 2.3f),
    GoldParticle(0.88f, 0.02f, 1.10f, 2.2f, 0.21f, 3.0f)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(
    viewModel: AppViewModel,
    modifier: Modifier = Modifier
) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var showExitDialog by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val loginState by viewModel.loginState.collectAsStateWithLifecycle()

    BackHandler {
        showExitDialog = true
    }

    if (showExitDialog) {
        ExitConfirmDialog(
            onDismiss = { showExitDialog = false },
            onConfirmExit = {
                showExitDialog = false
                (context as? Activity)?.finish()
            }
        )
    }

    // Soft entrance animation state
    var isVisible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        isVisible = true
    }

    val entranceAlpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(durationMillis = 600, easing = FastOutSlowInEasing),
        label = "entranceAlpha"
    )

    val entranceTranslationY by animateFloatAsState(
        targetValue = if (isVisible) 0f else 20f,
        animationSpec = tween(durationMillis = 600, easing = FastOutSlowInEasing),
        label = "entranceTranslationY"
    )

    // GPU-friendly ambient animations: light beam sway & continuous gold particles loop
    val infiniteTransition = rememberInfiniteTransition(label = "loginAmbient")

    val beamSway by infiniteTransition.animateFloat(
        initialValue = -0.18f,
        targetValue = 0.18f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 8000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "beamSway"
    )

    val particleProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 15000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "particleProgress"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
            .pointerInput(Unit) {
                detectTapGestures(onTap = {
                    focusManager.clearFocus()
                })
            }
    ) {
        // GPU-Optimized Background Layers: Edge-to-Edge Teal Aurora Light Beam + Particles
        Canvas(
            modifier = Modifier.fillMaxSize()
        ) {
            val w = size.width
            val h = size.height
            val maxDim = kotlin.math.hypot(w.toDouble(), h.toDouble()).toFloat()

            // Layer 1: Teal Aurora Light Beam across entire screen height
            val beamCenterX = w * (0.5f + beamSway)
            val beamCenterY = h * 0.45f

            // Full-screen radial glow
            drawRect(
                brush = androidx.compose.ui.graphics.Brush.radialGradient(
                    colors = listOf(
                        TealPrimary.copy(alpha = 0.18f),
                        TealAccent.copy(alpha = 0.08f),
                        DarkBg.copy(alpha = 0.02f)
                    ),
                    center = Offset(beamCenterX, beamCenterY),
                    radius = maxDim * 0.75f
                )
            )

            // Full-height diagonal linear gradient beam
            drawRect(
                brush = androidx.compose.ui.graphics.Brush.linearGradient(
                    colors = listOf(
                        TealAccent.copy(alpha = 0.10f),
                        TealPrimary.copy(alpha = 0.12f),
                        TealAccent.copy(alpha = 0.04f)
                    ),
                    start = Offset(beamCenterX - w * 0.5f, 0f),
                    end = Offset(beamCenterX + w * 0.5f, h)
                )
            )

            // Layer 2: Floating Dust Particles
            val particleColor = TealPrimary
            val totalHeightRange = h + 120.dp.toPx()

            loginGoldParticles.forEach { p ->
                val currentYProgress = (p.initialYRatio + particleProgress * p.speed) % 1.0f
                val yPos = currentYProgress * totalHeightRange - 60.dp.toPx()
                val swayPx = kotlin.math.sin((particleProgress * 2 * Math.PI + p.swayPhase).toDouble()).toFloat() * 14.dp.toPx()
                val xPos = p.xRatio * w + swayPx

                drawCircle(
                    color = particleColor.copy(alpha = p.alpha * 0.8f),
                    radius = p.radiusDp.dp.toPx(),
                    center = Offset(xPos, yPos)
                )
            }
        }

        // Safe Area Foreground Container for Login Card & Branding
        Box(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            // Center Login Content Card with Entrance Animation
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .graphicsLayer {
                        alpha = entranceAlpha
                        translationY = entranceTranslationY.dp.toPx()
                    },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // App Name Banner
                val tealTitleGradient = Brush.linearGradient(
                    colors = listOf(
                        TealPrimary,
                        TealAccent
                    )
                )
                Text(
                    text = "İşletme Paneli",
                    style = TextStyle(
                        brush = tealTitleGradient,
                        fontSize = 34.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        textAlign = TextAlign.Center
                    ),
                    modifier = Modifier.testTag("app_title")
                )
                Text(
                    text = "Personel · Çağrı · Analiz",
                    color = TextSecondary,
                    fontSize = 15.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(bottom = 24.dp)
                )

                // Username input
                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it.lowercase().trim() },
                    label = { Text("Kullanıcı Adı") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("username_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = TealPrimary,
                        focusedLabelColor = TealPrimary,
                        unfocusedBorderColor = TextSecondary.copy(alpha = 0.5f)
                    ),
                    leadingIcon = {
                        Icon(Icons.Default.Person, contentDescription = null, tint = TextSecondary)
                    }
                )

                // Password input
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Şifre") },
                    singleLine = true,
                    visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("password_input"),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = TealPrimary,
                        focusedLabelColor = TealPrimary,
                        unfocusedBorderColor = TextSecondary.copy(alpha = 0.5f)
                    ),
                    leadingIcon = {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = TextSecondary)
                    },
                    trailingIcon = {
                        val icon = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff
                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                            Icon(icon, contentDescription = "Şifre Göster/Gizle")
                        }
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Login Button
                Button(
                    onClick = { viewModel.login(username, password) },
                    enabled = loginState !is LoginState.Loading,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("login_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = TealPrimary,
                        contentColor = DarkBg,
                        disabledContainerColor = TealPrimary.copy(alpha = 0.5f)
                    ),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    if (loginState is LoginState.Loading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(24.dp),
                            color = DarkBg,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Text("Giriş Yap", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                }

                // Error Text
                if (loginState is LoginState.Error) {
                    Text(
                        text = (loginState as LoginState.Error).message,
                        color = ErrorColor,
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .padding(top = 8.dp)
                            .testTag("login_error_text")
                    )
                }
            }

            // Bottom Footer Branding Text
            Text(
                text = "QRMENUOFFICIAL",
                color = TextSecondary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = 2.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 8.dp)
            )
        }
    }
}

// --- 5.2 ADMIN MAIN SCREEN ---
@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun AdminMainScreen(
    viewModel: AppViewModel,
    onBranchClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val branches by viewModel.branches.collectAsStateWithLifecycle()
    var showAddDialog by remember { mutableStateOf(false) }
    var showEditDeleteDialog by remember { mutableStateOf(false) }
    var showExitDialog by remember { mutableStateOf(false) }
    var selectedBranch by remember { mutableStateOf<Branch?>(null) }
    val context = LocalContext.current

    BackHandler {
        showExitDialog = true
    }

    if (showExitDialog) {
        ExitConfirmDialog(
            onDismiss = { showExitDialog = false },
            onConfirmExit = {
                showExitDialog = false
                (context as? Activity)?.finish()
            }
        )
    }

    var branchName by remember { mutableStateOf("") }
    var branchSlug by remember { mutableStateOf("") }
    var isEditMode by remember { mutableStateOf(false) }

    Scaffold(
        modifier = modifier.background(DarkBg),
        topBar = {
            TopAppBar(
                title = { Text("Şubeler", fontWeight = FontWeight.Bold, color = TextPrimary) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBg),
                actions = {
                    IconButton(
                        onClick = { viewModel.logout() },
                        modifier = Modifier.testTag("logout_button")
                    ) {
                        Icon(Icons.Default.ExitToApp, contentDescription = "Çıkış Yap", tint = TealPrimary)
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    branchName = ""
                    branchSlug = ""
                    isEditMode = false
                    showAddDialog = true
                },
                containerColor = TealPrimary,
                contentColor = DarkBg,
                modifier = Modifier.testTag("add_branch_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Şube Ekle")
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(DarkBg)
        ) {
            if (branches.isEmpty()) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Storefront,
                        contentDescription = null,
                        tint = TextSecondary.copy(alpha = 0.5f),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Henüz şube eklenmemiş",
                        color = TextSecondary,
                        fontSize = 16.sp
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(branches, key = { it.id }) { branch ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .combinedClickable(
                                    onClick = { onBranchClick(branch.id) },
                                    onLongClick = {
                                        selectedBranch = branch
                                        branchName = branch.ad
                                        branchSlug = branch.slug
                                        showEditDeleteDialog = true
                                    }
                                )
                                .testTag("branch_card_${branch.id}"),
                            colors = CardDefaults.cardColors(containerColor = DarkSurface),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .background(TealPrimary.copy(alpha = 0.1f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Store, contentDescription = null, tint = TealPrimary)
                                }
                                Spacer(modifier = Modifier.width(16.dp))
                                Column {
                                    Text(
                                        text = branch.ad,
                                        color = TextPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp
                                    )
                                    Text(
                                        text = branch.slug,
                                        color = TextSecondary,
                                        fontSize = 14.sp
                                    )
                                }
                                Spacer(modifier = Modifier.weight(1f))
                                Icon(Icons.Default.ChevronRight, contentDescription = null, tint = TextSecondary)
                            }
                        }
                    }
                }
            }
        }
    }

    // Add / Edit Branch Dialog
    if (showAddDialog) {
        val context = LocalContext.current
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            containerColor = DarkSurface,
            title = {
                Text(
                    text = if (isEditMode) "Şubeyi Düzenle" else "Şube Ekle",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = branchName,
                        onValueChange = { branchName = it },
                        label = { Text("Şube Adı") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TealPrimary,
                            focusedLabelColor = TealPrimary,
                            unfocusedBorderColor = TextSecondary.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("dialog_branch_name_input")
                    )
                    OutlinedTextField(
                        value = branchSlug,
                        onValueChange = { branchSlug = it.lowercase().trim().replace(" ", "-") },
                        label = { Text("Slug (örn: merkez-sube)") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TealPrimary,
                            focusedLabelColor = TealPrimary,
                            unfocusedBorderColor = TextSecondary.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("dialog_branch_slug_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (isEditMode && selectedBranch != null) {
                            viewModel.updateBranch(
                                branchId = selectedBranch!!.id,
                                ad = branchName,
                                slug = branchSlug,
                                onSuccess = {
                                    showAddDialog = false
                                    Toast.makeText(context, "Şube güncellendi.", Toast.LENGTH_SHORT).show()
                                },
                                onError = {
                                    Toast.makeText(context, it, Toast.LENGTH_LONG).show()
                                }
                            )
                        } else {
                            viewModel.addBranch(
                                ad = branchName,
                                slug = branchSlug,
                                onSuccess = {
                                    showAddDialog = false
                                    Toast.makeText(context, "Şube eklendi.", Toast.LENGTH_SHORT).show()
                                },
                                onError = {
                                    Toast.makeText(context, it, Toast.LENGTH_LONG).show()
                                }
                            )
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TealPrimary, contentColor = DarkBg)
                ) {
                    Text("Kaydet", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Vazgeç", color = TextSecondary)
                }
            }
        )
    }

    // Long Press Edit/Delete Bottom Sheet or Dialog
    if (showEditDeleteDialog && selectedBranch != null) {
        val context = LocalContext.current
        AlertDialog(
            onDismissRequest = { showEditDeleteDialog = false },
            containerColor = DarkSurface,
            title = { Text(selectedBranch!!.ad, color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = { Text("Şube üzerinde yapmak istediğiniz işlemi seçin.", color = TextSecondary) },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(
                        onClick = {
                            showEditDeleteDialog = false
                            isEditMode = true
                            showAddDialog = true
                        }
                    ) {
                        Text("Düzenle", color = TealPrimary)
                    }
                    Button(
                        onClick = {
                            viewModel.deleteBranch(
                                branchId = selectedBranch!!.id,
                                onSuccess = {
                                    showEditDeleteDialog = false
                                    Toast.makeText(context, "Şube silindi.", Toast.LENGTH_SHORT).show()
                                },
                                onError = {
                                    Toast.makeText(context, it, Toast.LENGTH_LONG).show()
                                }
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ErrorColor, contentColor = TextPrimary)
                    ) {
                        Text("Sil", fontWeight = FontWeight.Bold)
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditDeleteDialog = false }) {
                    Text("İptal", color = TextSecondary)
                }
            }
        )
    }
}

// --- 5.2.1 BRANCH DETAIL SCREEN ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BranchDetailScreen(
    viewModel: AppViewModel,
    branchId: String,
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler {
        onBackClick()
    }

    val branches by viewModel.branches.collectAsStateWithLifecycle()
    val branchUsers by viewModel.branchUsers.collectAsStateWithLifecycle()
    val context = LocalContext.current

    val branch = remember(branches, branchId) {
        branches.find { it.id == branchId }
    }

    var showAddUserDialog by remember { mutableStateOf(false) }
    var userAd by remember { mutableStateOf("") }
    var userKullaniciAdi by remember { mutableStateOf("") }
    var userSifre by remember { mutableStateOf("") }
    var userRol by remember { mutableStateOf("mudur") } // mudur, garson
    var branchSection by remember { mutableIntStateOf(0) } // 0: Users, 1: Personel

    LaunchedEffect(branchId) {
        viewModel.listenToBranchUsers(branchId)
    }

    DisposableEffect(branchId) {
        onDispose {
            viewModel.stopListeningToBranchUsers()
        }
    }

    Scaffold(
        modifier = modifier.background(DarkBg),
        topBar = {
            TopAppBar(
                title = { Text(branch?.ad ?: "Şube Detay", fontWeight = FontWeight.Bold, color = TextPrimary) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBg),
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Geri", tint = TealPrimary)
                    }
                }
            )
        },
        floatingActionButton = {
            if (branchSection == 0) {
                FloatingActionButton(
                    onClick = {
                        userAd = ""
                        userKullaniciAdi = ""
                        userSifre = ""
                        userRol = "mudur"
                        showAddUserDialog = true
                    },
                    containerColor = TealPrimary,
                    contentColor = DarkBg,
                    modifier = Modifier.testTag("add_user_fab")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Kullanıcı Ekle")
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(DarkBg)
        ) {
            if (branch == null) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = TealPrimary)
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Button(
                            onClick = { branchSection = 0 },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (branchSection == 0) TealPrimary else DarkSurface,
                                contentColor = if (branchSection == 0) DarkBg else TextPrimary
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 2.dp, vertical = 6.dp)
                        ) {
                            Text("Kullanıcılar", fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
                        }
                        Button(
                            onClick = { branchSection = 1 },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (branchSection == 1) TealPrimary else DarkSurface,
                                contentColor = if (branchSection == 1) DarkBg else TextPrimary
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 2.dp, vertical = 6.dp)
                        ) {
                            Text("Personel", fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
                        }
                        Button(
                            onClick = { branchSection = 2 },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (branchSection == 2) TealPrimary else DarkSurface,
                                contentColor = if (branchSection == 2) DarkBg else TextPrimary
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 2.dp, vertical = 6.dp)
                        ) {
                            Text("Analiz", fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
                        }
                    }

                    if (branchSection == 1) {
                        PersonelTab(viewModel = viewModel, targetBranchId = branch.id)
                    } else if (branchSection == 2) {
                        AnalyticsTab(viewModel = viewModel)
                    } else {
                    // API Key Card
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkSurface),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "API Anahtarı",
                                    color = TextSecondary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = branch.apiKey,
                                    color = TealAccent,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.testTag("api_key_text")
                                )
                            }
                            IconButton(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    val clip = ClipData.newPlainText("API Key", branch.apiKey)
                                    clipboard.setPrimaryClip(clip)
                                    Toast.makeText(context, "API Anahtarı kopyalandı", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.testTag("copy_api_key_button")
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "Kopyala", tint = TealPrimary)
                            }
                        }
                    }

                    // Section Branch Location
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                            .testTag("branch_location_card"),
                        colors = CardDefaults.cardColors(containerColor = DarkSurface),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "Şube Konumu ve Vardiya Kısıtı",
                                    color = TextPrimary,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Icon(Icons.Default.LocationOn, contentDescription = null, tint = TealPrimary)
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            if (branch.lat != null && branch.lng != null) {
                                Text(
                                    text = "Kayıtlı Konum: ${String.format(java.util.Locale.US, "%.5f", branch.lat)}, ${String.format(java.util.Locale.US, "%.5f", branch.lng)}",
                                    color = TealAccent,
                                    fontSize = 13.sp
                                )
                            } else {
                                Text(
                                    text = "Şube konumu henüz ayarlanmadı.",
                                    color = TextSecondary,
                                    fontSize = 13.sp
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            var radiusInput by remember(branch.radius) { mutableStateOf((branch.radius ?: 150.0).toInt().toString()) }

                            OutlinedTextField(
                                value = radiusInput,
                                onValueChange = { radiusInput = it.filter { char -> char.isDigit() } },
                                label = { Text("Vardiya İzin Yarıçapı (Metre)") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = TealPrimary,
                                    focusedLabelColor = TealPrimary,
                                    unfocusedBorderColor = TextSecondary.copy(alpha = 0.5f)
                                ),
                                modifier = Modifier.fillMaxWidth().testTag("radius_input")
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            val locPermissionLauncher = rememberLauncherForActivityResult(
                                ActivityResultContracts.RequestMultiplePermissions()
                            ) { permissions ->
                                val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] ?: false
                                val coarseGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] ?: false
                                if (fineGranted || coarseGranted) {
                                    val radiusVal = radiusInput.toDoubleOrNull() ?: 150.0
                                    LocationUtils.getCurrentLocation(
                                        context = context,
                                        onLocationObtained = { loc ->
                                            viewModel.updateBranchLocation(
                                                branchId = branch.id,
                                                lat = loc.latitude,
                                                lng = loc.longitude,
                                                radius = radiusVal,
                                                onSuccess = { Toast.makeText(context, "Konum ayarlandı", Toast.LENGTH_SHORT).show() },
                                                onError = { err -> Toast.makeText(context, err, Toast.LENGTH_LONG).show() }
                                            )
                                        },
                                        onError = { err -> Toast.makeText(context, err, Toast.LENGTH_LONG).show() }
                                    )
                                } else {
                                    Toast.makeText(context, "Konum izni verilmedi", Toast.LENGTH_SHORT).show()
                                }
                            }

                            Button(
                                onClick = {
                                    val radiusVal = radiusInput.toDoubleOrNull() ?: 150.0
                                    if (LocationUtils.hasLocationPermission(context)) {
                                        LocationUtils.getCurrentLocation(
                                            context = context,
                                            onLocationObtained = { loc ->
                                                viewModel.updateBranchLocation(
                                                    branchId = branch.id,
                                                    lat = loc.latitude,
                                                    lng = loc.longitude,
                                                    radius = radiusVal,
                                                    onSuccess = { Toast.makeText(context, "Konum ayarlandı", Toast.LENGTH_SHORT).show() },
                                                    onError = { err -> Toast.makeText(context, err, Toast.LENGTH_LONG).show() }
                                                )
                                            },
                                            onError = { err -> Toast.makeText(context, err, Toast.LENGTH_LONG).show() }
                                        )
                                    } else {
                                        locPermissionLauncher.launch(
                                            arrayOf(
                                                Manifest.permission.ACCESS_FINE_LOCATION,
                                                Manifest.permission.ACCESS_COARSE_LOCATION
                                            )
                                        )
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = TealPrimary, contentColor = DarkBg),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth().testTag("set_branch_location_button")
                            ) {
                                Icon(Icons.Default.MyLocation, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Şube Konumunu Ayarla — Şu an buradayım", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }
                    }

                    // Section User List
                    Text(
                        text = "Kullanıcılar",
                        color = TextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )

                    if (branchUsers.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.PeopleOutline,
                                    contentDescription = null,
                                    tint = TextSecondary.copy(alpha = 0.5f),
                                    modifier = Modifier.size(48.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("Şubede kayıtlı personel bulunamadı.", color = TextSecondary, fontSize = 14.sp)
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(branchUsers, key = { it.uid }) { u ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("user_card_${u.uid}"),
                                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = u.ad,
                                                    color = TextPrimary,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 16.sp
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                // Role badge
                                                Box(
                                                    modifier = Modifier
                                                        .background(
                                                            if (u.rol == "mudur") TealPrimary.copy(alpha = 0.15f) else Color.Gray.copy(alpha = 0.15f),
                                                            RoundedCornerShape(4.dp)
                                                        )
                                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                                ) {
                                                    Text(
                                                        text = if (u.rol == "mudur") "Müdür" else "Garson",
                                                        color = if (u.rol == "mudur") TealAccent else TextPrimary.copy(alpha = 0.7f),
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                            }
                                            Text(
                                                text = u.kullaniciAdi,
                                                color = TextSecondary,
                                                fontSize = 13.sp
                                            )
                                        }
                                        Spacer(modifier = Modifier.weight(1f))
                                        IconButton(
                                            onClick = {
                                                viewModel.deleteUser(
                                                    uid = u.uid,
                                                    onSuccess = {
                                                        Toast.makeText(context, "Kullanıcı silindi.", Toast.LENGTH_SHORT).show()
                                                    },
                                                    onError = {
                                                        Toast.makeText(context, it, Toast.LENGTH_LONG).show()
                                                    }
                                                )
                                            },
                                            modifier = Modifier.testTag("delete_user_button_${u.uid}")
                                        ) {
                                            Icon(Icons.Default.Delete, contentDescription = "Sil", tint = ErrorColor)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    }
                }
            }
        }
    }

    // Add User Dialog
    if (showAddUserDialog) {
        AlertDialog(
            onDismissRequest = { showAddUserDialog = false },
            containerColor = DarkSurface,
            title = { Text("Kullanıcı Ekle", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Role Segmented selection (Müdür / Garson)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { userRol = "mudur" },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (userRol == "mudur") TealPrimary else DarkBg,
                                contentColor = if (userRol == "mudur") DarkBg else TextPrimary
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Müdür", fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = { userRol = "garson" },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (userRol == "garson") TealPrimary else DarkBg,
                                contentColor = if (userRol == "garson") DarkBg else TextPrimary
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Garson", fontWeight = FontWeight.Bold)
                        }
                    }

                    OutlinedTextField(
                        value = userAd,
                        onValueChange = { userAd = it },
                        label = { Text("Ad Soyad") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TealPrimary,
                            focusedLabelColor = TealPrimary,
                            unfocusedBorderColor = TextSecondary.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("dialog_user_ad_input")
                    )

                    OutlinedTextField(
                        value = userKullaniciAdi,
                        onValueChange = { userKullaniciAdi = it.lowercase().trim() },
                        label = { Text("Kullanıcı Adı") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TealPrimary,
                            focusedLabelColor = TealPrimary,
                            unfocusedBorderColor = TextSecondary.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("dialog_user_username_input")
                    )

                    OutlinedTextField(
                        value = userSifre,
                        onValueChange = { userSifre = it },
                        label = { Text("Şifre") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TealPrimary,
                            focusedLabelColor = TealPrimary,
                            unfocusedBorderColor = TextSecondary.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("dialog_user_password_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.addUser(
                            branchId = branchId,
                            ad = userAd,
                            kullaniciAdi = userKullaniciAdi,
                            sifre = userSifre,
                            rol = userRol,
                            onSuccess = {
                                showAddUserDialog = false
                                Toast.makeText(context, "Kullanıcı başarıyla oluşturuldu.", Toast.LENGTH_SHORT).show()
                            },
                            onError = {
                                Toast.makeText(context, it, Toast.LENGTH_LONG).show()
                            }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TealPrimary, contentColor = DarkBg)
                ) {
                    Text("Oluştur", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddUserDialog = false }) {
                    Text("Vazgeç", color = TextSecondary)
                }
            }
        )
    }
}

@Composable
fun SetBranchLocationDialog(
    viewModel: AppViewModel,
    branchId: String,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val currentBranch by viewModel.currentBranch.collectAsStateWithLifecycle()

    var radiusInput by remember(currentBranch?.radius) {
        mutableStateOf((currentBranch?.radius ?: 150.0).toInt().toString())
    }

    val locPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] ?: false
        val coarseGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] ?: false
        if (fineGranted || coarseGranted) {
            val radiusVal = radiusInput.toDoubleOrNull() ?: 150.0
            LocationUtils.getCurrentLocation(
                context = context,
                onLocationObtained = { loc ->
                    viewModel.updateBranchLocation(
                        branchId = branchId,
                        lat = loc.latitude,
                        lng = loc.longitude,
                        radius = radiusVal,
                        onSuccess = {
                            Toast.makeText(context, "Konum ayarlandı", Toast.LENGTH_SHORT).show()
                            onDismiss()
                        },
                        onError = { err -> Toast.makeText(context, err, Toast.LENGTH_LONG).show() }
                    )
                },
                onError = { err -> Toast.makeText(context, err, Toast.LENGTH_LONG).show() }
            )
        } else {
            Toast.makeText(context, "Konum izni verilmedi", Toast.LENGTH_SHORT).show()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.LocationOn, contentDescription = null, tint = TealPrimary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Şube Konumunu Ayarla", color = TextPrimary, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (currentBranch?.lat != null && currentBranch?.lng != null) {
                    Text(
                        text = "Mevcut Konum: ${String.format(java.util.Locale.US, "%.5f", currentBranch?.lat)}, ${String.format(java.util.Locale.US, "%.5f", currentBranch?.lng)}",
                        color = TealAccent,
                        fontSize = 13.sp
                    )
                } else {
                    Text(
                        text = "Şube konumu henüz ayarlanmadı.",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                }

                OutlinedTextField(
                    value = radiusInput,
                    onValueChange = { radiusInput = it.filter { char -> char.isDigit() } },
                    label = { Text("Mesafe Yarıçapı (Metre)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = TealPrimary,
                        focusedLabelColor = TealPrimary,
                        unfocusedBorderColor = TextSecondary.copy(alpha = 0.5f)
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("manager_radius_input")
                )

                Text(
                    text = "Butona bastığınızda cihazınızın anlık GPS konumu şubenizin konumu olarak kaydedilecektir.",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val radiusVal = radiusInput.toDoubleOrNull() ?: 150.0
                    if (LocationUtils.hasLocationPermission(context)) {
                        LocationUtils.getCurrentLocation(
                            context = context,
                            onLocationObtained = { loc ->
                                viewModel.updateBranchLocation(
                                    branchId = branchId,
                                    lat = loc.latitude,
                                    lng = loc.longitude,
                                    radius = radiusVal,
                                    onSuccess = {
                                        Toast.makeText(context, "Konum ayarlandı", Toast.LENGTH_SHORT).show()
                                        onDismiss()
                                    },
                                    onError = { err -> Toast.makeText(context, err, Toast.LENGTH_LONG).show() }
                                )
                            },
                            onError = { err -> Toast.makeText(context, err, Toast.LENGTH_LONG).show() }
                        )
                    } else {
                        locPermissionLauncher.launch(
                            arrayOf(
                                Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_COARSE_LOCATION
                            )
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = TealPrimary, contentColor = DarkBg),
                modifier = Modifier.testTag("manager_set_location_confirm_button")
            ) {
                Icon(Icons.Default.MyLocation, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Şube Konumunu Ayarla — Şu an buradayım", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Kapat", color = TextSecondary)
            }
        }
    )
}

// --- 5.3 MANAGER MAIN SCREEN ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManagerMainScreen(
    viewModel: AppViewModel,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var showLocationDialog by remember { mutableStateOf(false) }
    var showExitDialog by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    val approvedCallInfo by viewModel.approvedCallEvent.collectAsStateWithLifecycle()
    val userBranchId by viewModel.userBranchId.collectAsStateWithLifecycle()
    val context = LocalContext.current

    if (showSettings) {
        BackHandler {
            showSettings = false
        }
        SettingsScreen(onBackClick = { showSettings = false }, modifier = modifier)
        return
    }

    BackHandler {
        if (selectedTab != 0) {
            selectedTab = 0
        } else {
            showExitDialog = true
        }
    }

    if (showExitDialog) {
        ExitConfirmDialog(
            onDismiss = { showExitDialog = false },
            onConfirmExit = {
                showExitDialog = false
                (context as? Activity)?.finish()
            }
        )
    }

    Scaffold(
        modifier = modifier.background(DarkBg),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = when (selectedTab) {
                            0 -> "Bildirimler"
                            1 -> "Çağrı Geçmişi"
                            2 -> "Garsonlar"
                            3 -> "Personel"
                            else -> "Analiz"
                        },
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBg),
                actions = {
                    IconButton(
                        onClick = { showSettings = true },
                        modifier = Modifier.testTag("settings_button")
                    ) {
                        Icon(Icons.Default.Settings, contentDescription = "Ayarlar", tint = TextSecondary)
                    }
                    IconButton(
                        onClick = { showLocationDialog = true },
                        modifier = Modifier.testTag("manager_location_button")
                    ) {
                        Icon(Icons.Default.LocationOn, contentDescription = "Şube Konumu", tint = TextSecondary)
                    }
                    IconButton(
                        onClick = { viewModel.logout() },
                        modifier = Modifier.testTag("logout_button")
                    ) {
                        Icon(Icons.Default.ExitToApp, contentDescription = "Çıkış Yap", tint = TextSecondary)
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = DarkSurface,
                modifier = Modifier.testTag("bottom_nav")
            ) {
                val tabs = listOf(
                    Triple(0, "Bildirimler", Icons.Default.Notifications),
                    Triple(1, "Geçmiş", Icons.Default.History),
                    Triple(2, "Garsonlar", Icons.Default.People),
                    Triple(3, "Personel", Icons.Default.Badge),
                    Triple(4, "Analiz", Icons.Default.Analytics)
                )

                tabs.forEach { (index, label, icon) ->
                    val isSelected = selectedTab == index
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { selectedTab = index },
                        icon = {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                if (isSelected) {
                                    Box(
                                        modifier = Modifier
                                            .width(20.dp)
                                            .height(2.dp)
                                            .background(TealPrimary, RoundedCornerShape(1.dp))
                                    )
                                } else {
                                    Spacer(modifier = Modifier.height(2.dp))
                                }
                                Icon(icon, contentDescription = label)
                            }
                        },
                        label = { Text(label, fontSize = 12.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = TealPrimary,
                            selectedTextColor = TealPrimary,
                            indicatorColor = Color.Transparent,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        ),
                        modifier = when (index) {
                            1 -> Modifier.testTag("history_nav_item")
                            3 -> Modifier.testTag("personel_nav_item")
                            4 -> Modifier.testTag("analiz_nav_item")
                            else -> Modifier
                        }
                    )
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(DarkBg)
        ) {
            when (selectedTab) {
                0 -> NotificationsTab(viewModel)
                1 -> CallHistoryTab(viewModel)
                2 -> WaitersTab(viewModel)
                3 -> PersonelTab(viewModel)
                4 -> AnalyticsTab(viewModel)
            }

            if (showLocationDialog) {
                SetBranchLocationDialog(
                    viewModel = viewModel,
                    branchId = userBranchId,
                    onDismiss = { showLocationDialog = false }
                )
            }

            // Real-time top/bottom approval bar overlay
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .zIndex(10f)
            ) {
                LiveApprovalBanner(
                    info = approvedCallInfo,
                    onDismiss = { viewModel.clearApprovedCallEvent() }
                )
            }
        }
    }
}

// --- 5.4 WAITER SCREEN ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WaiterMainScreen(
    viewModel: AppViewModel,
    modifier: Modifier = Modifier
) {
    var showExitDialog by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    val approvedCallInfo by viewModel.approvedCallEvent.collectAsStateWithLifecycle()
    val context = LocalContext.current

    if (showSettings) {
        BackHandler {
            showSettings = false
        }
        SettingsScreen(onBackClick = { showSettings = false }, modifier = modifier)
        return
    }

    BackHandler {
        showExitDialog = true
    }

    if (showExitDialog) {
        ExitConfirmDialog(
            onDismiss = { showExitDialog = false },
            onConfirmExit = {
                showExitDialog = false
                (context as? Activity)?.finish()
            }
        )
    }

    Scaffold(
        modifier = modifier.background(DarkBg),
        topBar = {
            TopAppBar(
                title = { Text("Bildirimler", fontWeight = FontWeight.Bold, color = TextPrimary) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBg),
                actions = {
                    IconButton(
                        onClick = { showSettings = true },
                        modifier = Modifier.testTag("settings_button")
                    ) {
                        Icon(Icons.Default.Settings, contentDescription = "Ayarlar", tint = TealPrimary)
                    }
                    IconButton(
                        onClick = { viewModel.logout() },
                        modifier = Modifier.testTag("logout_button")
                    ) {
                        Icon(Icons.Default.ExitToApp, contentDescription = "Çıkış Yap", tint = TealPrimary)
                    }
                }
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(DarkBg)
        ) {
            NotificationsTab(viewModel)

            // Real-time top/bottom approval bar overlay
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .zIndex(10f)
            ) {
                LiveApprovalBanner(
                    info = approvedCallInfo,
                    onDismiss = { viewModel.clearApprovedCallEvent() }
                )
            }
        }
    }
}

// --- TAB 1: NOTIFICATIONS (Manager & Waiter Common) ---
@Composable
fun NotificationsTab(viewModel: AppViewModel) {
    val calls by viewModel.calls.collectAsStateWithLifecycle()
    val userBranchId by viewModel.userBranchId.collectAsStateWithLifecycle()
    val userRole by viewModel.userRole.collectAsStateWithLifecycle()
    val activeShift by viewModel.activeShift.collectAsStateWithLifecycle()
    val clearedTs by viewModel.clearedNotificationTimestamp.collectAsStateWithLifecycle()
    var showClearDialog by remember { mutableStateOf(false) }
    var cancelCallId by remember { mutableStateOf<String?>(null) }
    var cancelReason by remember { mutableStateOf("") }
    var cancelReasonError by remember { mutableStateOf(false) }
    val context = LocalContext.current

    val startShiftPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] ?: false
        val coarseGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] ?: false
        if (fineGranted || coarseGranted) {
            viewModel.startShiftWithLocationCheck(
                context = context,
                onSuccess = { Toast.makeText(context, "Vardiya başlatıldı", Toast.LENGTH_SHORT).show() },
                onError = { msg -> Toast.makeText(context, msg, Toast.LENGTH_LONG).show() }
            )
        } else {
            Toast.makeText(context, "Vardiya başlatmak için konum izni gerekli", Toast.LENGTH_LONG).show()
        }
    }

    LaunchedEffect(Unit) {
        viewModel.ensureShiftListener()
    }

    DisposableEffect(userBranchId) {
        if (userBranchId.isNotEmpty()) {
            viewModel.startCallsListener(userBranchId)
        }
        onDispose {
            viewModel.stopCallsListener()
        }
    }

    // Timer to update elapsed seconds and expire approved calls after 120s
    var currentTime by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            currentTime = System.currentTimeMillis()
        }
    }

    // Filter calls: approved or cancelled calls disappear 120 seconds after action OR if cleared by manager
    val visibleCalls = remember(calls, currentTime, clearedTs) {
        calls.filter { call ->
            if (call.durum == "onaylandi") {
                val onayAtMs = call.onaylandiAt?.toDate()?.time ?: call.createdAt?.toDate()?.time ?: 0L
                if (clearedTs > 0L && onayAtMs <= clearedTs) {
                    false // hidden by manager clear button
                } else {
                    val diffSec = (currentTime - onayAtMs) / 1000
                    diffSec <= 120
                }
            } else if (call.durum == "iptal") {
                val iptalAtMs = call.iptalAt?.toDate()?.time ?: call.createdAt?.toDate()?.time ?: 0L
                if (clearedTs > 0L && iptalAtMs <= clearedTs) {
                    false // hidden by manager clear button
                } else {
                    val diffSec = (currentTime - iptalAtMs) / 1000
                    diffSec <= 120
                }
            } else {
                true // bekliyor calls stay indefinitely until approved or cancelled
            }
        }
    }

    val isWaiter = userRole == "garson"
    val isShiftActive = activeShift != null

    Column(modifier = Modifier.fillMaxSize()) {
        // Clear Button for Manager/Admin at top right
        if (!isWaiter) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Canlı Bildirimler",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                    Text(
                        text = "Aktif bekleyen ve son 120sn onaylanan çağrılar",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
                Button(
                    onClick = { showClearDialog = true },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = TealPrimary.copy(alpha = 0.15f),
                        contentColor = TealPrimary
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier = Modifier.testTag("clear_approved_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.CleaningServices,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Temizle", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }

        // Shift status card for garson role at the VERY TOP
        if (isWaiter) {
            if (!isShiftActive) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .testTag("shift_card_closed"),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    border = BorderStroke(1.dp, BorderColor),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Button(
                            onClick = {
                                if (LocationUtils.hasLocationPermission(context)) {
                                    viewModel.startShiftWithLocationCheck(
                                        context = context,
                                        onSuccess = {
                                            Toast.makeText(context, "Vardiya başlatıldı", Toast.LENGTH_SHORT).show()
                                        },
                                        onError = { msg ->
                                            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                        }
                                    )
                                } else {
                                    startShiftPermissionLauncher.launch(
                                        arrayOf(
                                            Manifest.permission.ACCESS_FINE_LOCATION,
                                            Manifest.permission.ACCESS_COARSE_LOCATION
                                        )
                                    )
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("start_shift_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = TealPrimary,
                                contentColor = DarkBg
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(22.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Vardiyayı Başlat", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Vardiyanı başlatınca çağrılar görünecek",
                            color = TextSecondary,
                            fontSize = 14.sp
                        )
                    }
                }
            } else {
                val isBreak = activeShift?.molada == true
                val cardBorder = if (isBreak) StatusAmber.copy(alpha = 0.5f) else StatusGreen.copy(alpha = 0.5f)

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                        .testTag("shift_card_open"),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    border = BorderStroke(1.dp, cardBorder),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            if (isBreak) {
                                val molaTime = remember(activeShift?.molaBaslangic) {
                                    activeShift?.molaBaslangic?.toDate()?.let {
                                        java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(it)
                                    } ?: ""
                                }
                                Text(
                                    text = if (molaTime.isNotEmpty()) "Molada — $molaTime'den beri" else "Molada",
                                    color = StatusAmber,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            } else {
                                val baslangicTime = remember(activeShift?.baslangic) {
                                    activeShift?.baslangic?.toDate()?.let {
                                        java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(it)
                                    } ?: ""
                                }
                                Text(
                                    text = if (baslangicTime.isNotEmpty()) "Vardiya açık — $baslangicTime'den beri" else "Vardiya açık",
                                    color = StatusGreen,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            if (isBreak) {
                                Surface(
                                    color = StatusAmber.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = "MOLA",
                                        color = StatusAmber,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (isBreak) {
                                Button(
                                    onClick = {
                                        viewModel.endBreak(
                                            onSuccess = {
                                                Toast.makeText(context, "Moladan dönüldü", Toast.LENGTH_SHORT).show()
                                            },
                                            onError = { msg ->
                                                Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                            }
                                        )
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = TealPrimary,
                                        contentColor = DarkBg
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(40.dp)
                                        .testTag("end_break_button")
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Moladan Dön", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                            } else {
                                OutlinedButton(
                                    onClick = {
                                        viewModel.startBreak(
                                            onSuccess = {
                                                Toast.makeText(context, "Molaya çıkıldı", Toast.LENGTH_SHORT).show()
                                            },
                                            onError = { msg ->
                                                Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                            }
                                        )
                                    },
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        contentColor = StatusAmber
                                    ),
                                    border = BorderStroke(1.dp, StatusAmber),
                                    shape = RoundedCornerShape(10.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(40.dp)
                                        .testTag("start_break_button")
                                ) {
                                    Icon(Icons.Default.Pause, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Molaya Çık", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                            }

                            OutlinedButton(
                                onClick = {
                                    viewModel.endShift(
                                        onSuccess = {
                                            Toast.makeText(context, "Vardiya bitirildi", Toast.LENGTH_SHORT).show()
                                        },
                                        onError = { msg ->
                                            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                        }
                                    )
                                },
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = StatusRed
                                ),
                                border = BorderStroke(1.dp, StatusRed),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(40.dp)
                                    .testTag("end_shift_button")
                            ) {
                                Text("Vardiyayı Bitir", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        }

        // Call List or Empty State
        if (isWaiter && !isShiftActive) {
            // Hide calls list when shift is closed
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Schedule,
                        contentDescription = null,
                        tint = TextSecondary.copy(alpha = 0.4f),
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Vardiya Kapalı",
                        color = TextSecondary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        } else if (visibleCalls.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.NotificationsNone,
                        contentDescription = null,
                        tint = TextSecondary.copy(alpha = 0.5f),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Çağrı yok",
                        color = TextSecondary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                items(visibleCalls, key = { it.id }) { call ->
                    val isApproved = call.durum == "onaylandi"
                    val isCancelled = call.durum == "iptal"

                    val borderStroke = when {
                        isApproved -> BorderStroke(1.dp, StatusGreen.copy(alpha = 0.4f))
                        isCancelled -> BorderStroke(1.dp, StatusRed.copy(alpha = 0.4f))
                        else -> BorderStroke(1.dp, BorderColor)
                    }

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("call_card_${call.id}"),
                        colors = CardDefaults.cardColors(containerColor = DarkSurface),
                        border = borderStroke,
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Left: Table No & Elapsed time / Approval status / Cancel status
                                Column(
                                    horizontalAlignment = Alignment.Start,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(
                                        text = FormatUtils.formatMasaTitle(call.masaNo),
                                        color = TextPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    val statusSubtext = when {
                                        isApproved -> {
                                            if (call.createdAt != null && call.onaylandiAt != null) {
                                                val sec = (call.onaylandiAt.toDate().time - call.createdAt.toDate().time) / 1000
                                                if (sec >= 0) "$sec. saniyede onaylandı" else "${call.onaylayanAd.ifEmpty { "Personel" }} onayladı"
                                            } else if (call.onaylayanAd.isNotEmpty()) {
                                                "${call.onaylayanAd} onayladı"
                                            } else {
                                                "Onaylandı"
                                            }
                                        }
                                        isCancelled -> {
                                            val iptalEden = call.iptalEdenAd.ifEmpty { "Personel" }
                                            "İptal edildi — $iptalEden"
                                        }
                                        else -> formatPendingCallTime(call.createdAt, currentTime)
                                    }

                                    Text(
                                        text = statusSubtext,
                                        color = when {
                                            isApproved -> StatusGreen
                                            isCancelled -> StatusRed
                                            else -> TextSecondary
                                        },
                                        fontSize = 12.sp,
                                        fontWeight = if (isCancelled) FontWeight.SemiBold else FontWeight.Normal
                                    )

                                    if (isCancelled && call.iptalNedeni.isNotEmpty()) {
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = "Neden: ${call.iptalNedeni}",
                                            color = StatusRed,
                                            fontSize = 11.sp,
                                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.width(8.dp))

                                // Center: Call type Badge
                                val badgeBg = when (call.tip) {
                                    "siparis" -> StatusGreen.copy(alpha = 0.15f)
                                    else -> StatusTeal.copy(alpha = 0.15f)
                                }
                                val badgeTextColor = when (call.tip) {
                                    "siparis" -> StatusGreen
                                    else -> StatusTeal
                                }
                                val badgeLabel = when (call.tip) {
                                    "siparis" -> "Sipariş"
                                    "hesap" -> "Hesap İstiyor"
                                    else -> "Garson Çağırıyor"
                                }

                                Box(
                                    modifier = Modifier
                                        .background(badgeBg, RoundedCornerShape(8.dp))
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = badgeLabel,
                                        color = badgeTextColor,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                // Right: Actions or Status
                                if (isApproved) {
                                    val onaylayan = call.onaylayanAd.ifEmpty { "Personel" }
                                    Text(
                                        text = "✓ $onaylayan onayladı",
                                        color = StatusGreen,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.testTag("approved_text_${call.id}")
                                    )
                                } else if (isCancelled) {
                                    Text(
                                        text = "✕ İptal",
                                        color = StatusRed,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.testTag("cancelled_text_${call.id}")
                                    )
                                } else {
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        if (call.tip == "siparis") {
                                            OutlinedButton(
                                                onClick = {
                                                    cancelCallId = call.id
                                                    cancelReason = ""
                                                    cancelReasonError = false
                                                },
                                                colors = ButtonDefaults.outlinedButtonColors(
                                                    contentColor = StatusRed
                                                ),
                                                border = BorderStroke(1.dp, StatusRed),
                                                shape = RoundedCornerShape(10.dp),
                                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                                modifier = Modifier
                                                    .height(40.dp)
                                                    .testTag("cancel_button_${call.id}")
                                            ) {
                                                Text("İptal", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                            }
                                        }

                                        Button(
                                            onClick = {
                                                viewModel.approveCall(
                                                    callId = call.id,
                                                    onError = { errorMsg ->
                                                        Toast.makeText(context, "Onay hatası: $errorMsg", Toast.LENGTH_LONG).show()
                                                    }
                                                )
                                            },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = TealPrimary,
                                                contentColor = DarkBg
                                            ),
                                            shape = RoundedCornerShape(10.dp),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                            modifier = Modifier
                                                .height(40.dp)
                                                .testTag("approve_button_${call.id}")
                                        ) {
                                            Text("Onayla", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        }
                                    }
                                }
                            }

                            // Body for Sipariş products list
                            if (call.tip == "siparis" && call.items.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(12.dp))
                                HorizontalDivider(color = BorderColor, thickness = 1.dp)
                                Spacer(modifier = Modifier.height(10.dp))

                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    call.items.forEach { item ->
                                        Column(modifier = Modifier.fillMaxWidth()) {
                                            Text(
                                                text = "• ${item.adet}x ${item.urunAdi}",
                                                color = TextPrimary,
                                                fontWeight = FontWeight.Medium,
                                                fontSize = 14.sp
                                            )

                                            val hasError = item.ceviri_hata == true
                                            val noteToShow = if (hasError) {
                                                item.notOrijinal
                                            } else {
                                                item.notTr.takeIf { !it.isNullOrEmpty() } ?: item.notOrijinal
                                            }

                                            if (!noteToShow.isNullOrEmpty()) {
                                                Spacer(modifier = Modifier.height(2.dp))
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    modifier = Modifier.padding(start = 12.dp)
                                                ) {
                                                    Text(
                                                        text = "Not: $noteToShow",
                                                        color = TextSecondary,
                                                        fontSize = 12.sp,
                                                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                                                    )
                                                    if (hasError) {
                                                        Spacer(modifier = Modifier.width(6.dp))
                                                        Text(
                                                            text = "(çevrilemedi)",
                                                            color = StatusAmber,
                                                            fontSize = 11.sp,
                                                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                                                            fontWeight = FontWeight.SemiBold
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (cancelCallId != null) {
        val targetCallId = cancelCallId!!
        AlertDialog(
            onDismissRequest = {
                cancelCallId = null
                cancelReason = ""
                cancelReasonError = false
            },
            containerColor = DarkSurface,
            title = {
                Text(
                    text = "Siparişi İptal Et",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column {
                    Text(
                        text = "Lütfen siparişin iptal edilme nedenini giriniz:",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = cancelReason,
                        onValueChange = {
                            cancelReason = it
                            if (it.trim().isNotEmpty()) cancelReasonError = false
                        },
                        label = { Text("İptal nedeni") },
                        isError = cancelReasonError,
                        singleLine = false,
                        maxLines = 3,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TealPrimary,
                            unfocusedBorderColor = TextSecondary,
                            focusedLabelColor = TealPrimary,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            errorBorderColor = Color(0xFFD32F2F),
                            errorLabelColor = Color(0xFFD32F2F)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("cancel_reason_input")
                    )
                    if (cancelReasonError) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Lütfen iptal nedenini giriniz.",
                            color = Color(0xFFD32F2F),
                            fontSize = 11.sp
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val trimmed = cancelReason.trim()
                        if (trimmed.isEmpty()) {
                            cancelReasonError = true
                            Toast.makeText(context, "Lütfen iptal nedenini giriniz", Toast.LENGTH_SHORT).show()
                        } else {
                            viewModel.cancelCall(
                                callId = targetCallId,
                                reason = trimmed,
                                onSuccess = {
                                    Toast.makeText(context, "Sipariş iptal edildi", Toast.LENGTH_SHORT).show()
                                }
                            )
                            cancelCallId = null
                            cancelReason = ""
                            cancelReasonError = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFD32F2F),
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("confirm_cancel_button")
                ) {
                    Text("İptal Et", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        cancelCallId = null
                        cancelReason = ""
                        cancelReasonError = false
                    },
                    modifier = Modifier.testTag("dismiss_cancel_button")
                ) {
                    Text("Vazgeç", color = TextSecondary)
                }
            }
        )
    }

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            containerColor = DarkSurface,
            title = { Text("Bildirimleri Temizle", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = { Text("Onaylanmış bildirimler temizlensin mi?", color = TextSecondary) },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.clearApprovedNotifications()
                        showClearDialog = false
                        Toast.makeText(context, "Onaylanmış bildirimler temizlendi.", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TealPrimary, contentColor = DarkBg)
                ) {
                    Text("Temizle", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearDialog = false }) {
                    Text("Vazgeç", color = TextSecondary)
                }
            }
        )
    }
}

// --- TAB 2: CALL HISTORY (Manager & Admin) ---
@Composable
fun CallHistoryTab(viewModel: AppViewModel) {
    val calls by viewModel.calls.collectAsStateWithLifecycle()
    val userBranchId by viewModel.userBranchId.collectAsStateWithLifecycle()

    DisposableEffect(userBranchId) {
        if (userBranchId.isNotEmpty()) {
            viewModel.startCallsListener(userBranchId)
        }
        onDispose {
            viewModel.stopCallsListener()
        }
    }

    var activeFilter by remember { mutableStateOf(StaffDateFilter.TODAY) }
    var showCustomDatePickerDialog by remember { mutableStateOf(false) }

    var customStartCal by remember {
        mutableStateOf(java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 0)
            set(java.util.Calendar.MINUTE, 0)
            set(java.util.Calendar.SECOND, 0)
            set(java.util.Calendar.MILLISECOND, 0)
        })
    }

    var customEndCal by remember {
        mutableStateOf(java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 23)
            set(java.util.Calendar.MINUTE, 59)
            set(java.util.Calendar.SECOND, 59)
            set(java.util.Calendar.MILLISECOND, 999)
        })
    }

    val customRangeStr = remember(customStartCal, customEndCal) {
        val startFormatted = java.text.SimpleDateFormat("d MMM", java.util.Locale("tr")).format(customStartCal.time)
        val endFormatted = java.text.SimpleDateFormat("d MMM", java.util.Locale("tr")).format(customEndCal.time)
        "$startFormatted – $endFormatted"
    }

    val (rangeStartMs, rangeEndMs) = remember(activeFilter, customStartCal, customEndCal) {
        when (activeFilter) {
            StaffDateFilter.TODAY -> {
                val cal = java.util.Calendar.getInstance()
                cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
                cal.set(java.util.Calendar.MINUTE, 0)
                cal.set(java.util.Calendar.SECOND, 0)
                cal.set(java.util.Calendar.MILLISECOND, 0)
                Pair(cal.timeInMillis, Long.MAX_VALUE)
            }
            StaffDateFilter.WEEK -> {
                val cal = java.util.Calendar.getInstance()
                cal.firstDayOfWeek = java.util.Calendar.MONDAY
                cal.set(java.util.Calendar.DAY_OF_WEEK, java.util.Calendar.MONDAY)
                cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
                cal.set(java.util.Calendar.MINUTE, 0)
                cal.set(java.util.Calendar.SECOND, 0)
                cal.set(java.util.Calendar.MILLISECOND, 0)
                if (cal.timeInMillis > System.currentTimeMillis()) {
                    cal.add(java.util.Calendar.DAY_OF_MONTH, -7)
                }
                Pair(cal.timeInMillis, Long.MAX_VALUE)
            }
            StaffDateFilter.MONTH -> {
                val cal = java.util.Calendar.getInstance()
                cal.set(java.util.Calendar.DAY_OF_MONTH, 1)
                cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
                cal.set(java.util.Calendar.MINUTE, 0)
                cal.set(java.util.Calendar.SECOND, 0)
                cal.set(java.util.Calendar.MILLISECOND, 0)
                Pair(cal.timeInMillis, Long.MAX_VALUE)
            }
            StaffDateFilter.CUSTOM -> {
                Pair(customStartCal.timeInMillis, customEndCal.timeInMillis)
            }
        }
    }

    val historyCalls = remember(calls, rangeStartMs, rangeEndMs) {
        calls.filter { call ->
            (call.durum == "onaylandi" || call.durum == "iptal") && run {
                val ts = call.iptalAt?.toDate()?.time ?: call.onaylandiAt?.toDate()?.time ?: call.createdAt?.toDate()?.time ?: 0L
                ts in rangeStartMs..rangeEndMs
            }
        }.sortedByDescending { call ->
            call.iptalAt?.toDate()?.time ?: call.onaylandiAt?.toDate()?.time ?: call.createdAt?.toDate()?.time ?: 0L
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Column(modifier = Modifier.padding(bottom = 12.dp)) {
            Text(
                text = "Çağrı Geçmişi",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Text(
                text = "Seçilen filtredeki tüm onaylanmış ve iptal edilmiş çağrılar saklanır",
                color = TextSecondary,
                fontSize = 12.sp
            )
        }

        // Date Filter Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            FilterTabButton(
                title = "Bugün",
                isSelected = activeFilter == StaffDateFilter.TODAY,
                onClick = { activeFilter = StaffDateFilter.TODAY },
                testTag = "call_history_filter_today",
                modifier = Modifier.weight(1f)
            )
            FilterTabButton(
                title = "Bu Hafta",
                isSelected = activeFilter == StaffDateFilter.WEEK,
                onClick = { activeFilter = StaffDateFilter.WEEK },
                testTag = "call_history_filter_week",
                modifier = Modifier.weight(1f)
            )
            FilterTabButton(
                title = "Bu Ay",
                isSelected = activeFilter == StaffDateFilter.MONTH,
                onClick = { activeFilter = StaffDateFilter.MONTH },
                testTag = "call_history_filter_month",
                modifier = Modifier.weight(1f)
            )
            FilterTabButton(
                title = if (activeFilter == StaffDateFilter.CUSTOM) customRangeStr else "Tarih Seç",
                isSelected = activeFilter == StaffDateFilter.CUSTOM,
                onClick = { showCustomDatePickerDialog = true },
                testTag = "call_history_filter_custom",
                modifier = Modifier.weight(1.2f)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (historyCalls.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = null,
                        tint = TextSecondary.copy(alpha = 0.4f),
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Bu aralıkta kayıt yok",
                        color = TextSecondary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        } else {
            val dateTimeFormat = remember { java.text.SimpleDateFormat("dd.MM.yyyy HH:mm", java.util.Locale("tr")) }

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                items(historyCalls, key = { it.id }) { call ->
                    val isCancelled = call.durum == "iptal"
                    val isSiparis = call.tip == "siparis"
                    val isHesap = call.tip == "hesap"

                    val islemTarihi = if (isCancelled) {
                        call.iptalAt?.toDate() ?: call.createdAt?.toDate()
                    } else {
                        call.onaylandiAt?.toDate() ?: call.createdAt?.toDate()
                    }
                    val tarihSaatStr = if (islemTarihi != null) dateTimeFormat.format(islemTarihi) else "-"
                    val personName = if (isCancelled) {
                        call.iptalEdenAd.ifEmpty { "Personel" }
                    } else {
                        call.onaylayanAd.ifEmpty { "Personel" }
                    }

                    val iconVector = when {
                        isCancelled -> Icons.Default.Cancel
                        isSiparis -> Icons.Default.Restaurant
                        isHesap -> Icons.Default.ReceiptLong
                        else -> Icons.Default.Notifications
                    }

                    val iconBg = when {
                        isCancelled -> StatusRed.copy(alpha = 0.15f)
                        isSiparis -> StatusGreen.copy(alpha = 0.15f)
                        else -> StatusTeal.copy(alpha = 0.15f)
                    }

                    val iconTint = when {
                        isCancelled -> StatusRed
                        isSiparis -> StatusGreen
                        else -> StatusTeal
                    }

                    val tipStr = when {
                        isCancelled -> "İptal"
                        isSiparis -> "Sipariş (${call.items.size} ürün)"
                        isHesap -> "Hesap"
                        else -> "Garson"
                    }

                    var isExpanded by remember { mutableStateOf(false) }

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(enabled = isSiparis && call.items.isNotEmpty()) { isExpanded = !isExpanded }
                            .testTag("history_call_card_${call.id}"),
                        colors = CardDefaults.cardColors(containerColor = DarkSurface),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Left Icon
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .background(iconBg, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = iconVector,
                                        contentDescription = null,
                                        tint = iconTint,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = FormatUtils.formatMasaTitle(call.masaNo),
                                            color = TextPrimary,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 16.sp
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Box(
                                            modifier = Modifier
                                                .background(iconBg, RoundedCornerShape(4.dp))
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = tipStr,
                                                color = iconTint,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))

                                    if (isCancelled) {
                                        Text(
                                            text = "$personName iptal etti — $tarihSaatStr",
                                            color = Color(0xFFEF5350),
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Medium
                                        )
                                        if (call.iptalNedeni.isNotEmpty()) {
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = "Neden: ${call.iptalNedeni}",
                                                color = TextSecondary,
                                                fontSize = 12.sp,
                                                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                                            )
                                        }
                                    } else {
                                        Text(
                                            text = "$personName onayladı — $tarihSaatStr",
                                            color = TextSecondary,
                                            fontSize = 12.sp
                                        )
                                    }
                                }

                                if (isSiparis && call.items.isNotEmpty()) {
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Icon(
                                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                        contentDescription = "Detay",
                                        tint = TextSecondary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }

                            if (isSiparis && isExpanded && call.items.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(10.dp))
                                HorizontalDivider(color = TextSecondary.copy(alpha = 0.2f), thickness = 1.dp)
                                Spacer(modifier = Modifier.height(8.dp))

                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    call.items.forEach { item ->
                                        Column(modifier = Modifier.fillMaxWidth()) {
                                            Text(
                                                text = "• ${item.adet}x ${item.urunAdi}",
                                                color = TextPrimary,
                                                fontWeight = FontWeight.Medium,
                                                fontSize = 13.sp
                                            )

                                            val hasError = item.ceviri_hata == true
                                            val noteToShow = if (hasError) {
                                                item.notOrijinal
                                            } else {
                                                item.notTr.takeIf { !it.isNullOrEmpty() } ?: item.notOrijinal
                                            }

                                            if (!noteToShow.isNullOrEmpty()) {
                                                Spacer(modifier = Modifier.height(2.dp))
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    modifier = Modifier.padding(start = 12.dp)
                                                ) {
                                                    Text(
                                                        text = "Not: $noteToShow",
                                                        color = TextSecondary,
                                                        fontSize = 11.sp,
                                                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                                                    )
                                                    if (hasError) {
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Text(
                                                            text = "(çevrilemedi)",
                                                            color = Color(0xFFFFB300),
                                                            fontSize = 10.sp,
                                                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCustomDatePickerDialog) {
        CustomDateRangePickerDialog(
            initialStartCal = customStartCal,
            initialEndCal = customEndCal,
            onDismiss = { showCustomDatePickerDialog = false },
            onConfirm = { startCal, endCal ->
                customStartCal = startCal
                customEndCal = endCal
                activeFilter = StaffDateFilter.CUSTOM
                showCustomDatePickerDialog = false
            }
        )
    }
}

// --- TAB 3: WAITERS (Manager) ---
@Composable
fun WaitersTab(viewModel: AppViewModel) {
    val waiters by viewModel.waiters.collectAsStateWithLifecycle()
    val branchId by viewModel.userBranchId.collectAsStateWithLifecycle()
    var showAddDialog by remember { mutableStateOf(false) }
    var waiterToDelete by remember { mutableStateOf<User?>(null) }

    var waiterAd by remember { mutableStateOf("") }
    var waiterUsername by remember { mutableStateOf("") }
    var waiterSifre by remember { mutableStateOf("") }
    val context = LocalContext.current

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = DarkBg,
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    waiterAd = ""
                    waiterUsername = ""
                    waiterSifre = ""
                    showAddDialog = true
                },
                containerColor = TealPrimary,
                contentColor = DarkBg,
                modifier = Modifier.testTag("add_waiter_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Garson Ekle")
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(DarkBg)
        ) {
            if (waiters.isEmpty()) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.PeopleOutline,
                        contentDescription = null,
                        tint = TextSecondary.copy(alpha = 0.5f),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Henüz garson eklenmemiş",
                        color = TextSecondary,
                        fontSize = 16.sp
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(waiters, key = { it.uid }) { waiter ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("waiter_card_${waiter.uid}"),
                            colors = CardDefaults.cardColors(containerColor = DarkSurface),
                            border = BorderStroke(1.dp, BorderColor),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .background(TealPrimary.copy(alpha = 0.1f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Person, contentDescription = null, tint = TealPrimary)
                                }
                                Spacer(modifier = Modifier.width(16.dp))
                                Column {
                                    Text(
                                        text = waiter.ad,
                                        color = TextPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp
                                    )
                                    Text(
                                        text = waiter.kullaniciAdi,
                                        color = TextSecondary,
                                        fontSize = 13.sp
                                    )
                                }
                                Spacer(modifier = Modifier.weight(1f))
                                IconButton(
                                    onClick = { waiterToDelete = waiter },
                                    modifier = Modifier.testTag("delete_waiter_button_${waiter.uid}")
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Sil", tint = StatusRed)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (waiterToDelete != null) {
        val targetWaiter = waiterToDelete
        AlertDialog(
            onDismissRequest = { waiterToDelete = null },
            containerColor = DarkSurface,
            title = {
                Text(
                    text = "Garsonu Sil",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = "${targetWaiter?.ad?.ifEmpty { targetWaiter.kullaniciAdi }} silinsin mi? Bu işlem geri alınamaz.",
                    color = TextSecondary,
                    fontSize = 14.sp
                )
            },
            confirmButton = {
                OutlinedButton(
                    onClick = {
                        val uidToDelete = targetWaiter?.uid ?: ""
                        waiterToDelete = null
                        if (uidToDelete.isNotEmpty()) {
                            viewModel.deleteUser(
                                uid = uidToDelete,
                                onSuccess = {
                                    Toast.makeText(context, "Garson silindi.", Toast.LENGTH_SHORT).show()
                                },
                                onError = { msg ->
                                    Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                }
                            )
                        }
                    },
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = StatusRed
                    ),
                    border = BorderStroke(1.dp, StatusRed),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("confirm_delete_waiter_button")
                ) {
                    Text("Sil", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { waiterToDelete = null },
                    modifier = Modifier.testTag("cancel_delete_waiter_button")
                ) {
                    Text("İptal", color = TextSecondary)
                }
            }
        )
    }

    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            containerColor = DarkSurface,
            title = { Text("Garson Ekle", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = waiterAd,
                        onValueChange = { waiterAd = it },
                        label = { Text("Garson Adı") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TealPrimary,
                            focusedLabelColor = TealPrimary,
                            unfocusedBorderColor = TextSecondary.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("dialog_waiter_ad_input")
                    )
                    OutlinedTextField(
                        value = waiterUsername,
                        onValueChange = { waiterUsername = it.lowercase().trim() },
                        label = { Text("Kullanıcı Adı") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TealPrimary,
                            focusedLabelColor = TealPrimary,
                            unfocusedBorderColor = TextSecondary.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("dialog_waiter_username_input")
                    )
                    OutlinedTextField(
                        value = waiterSifre,
                        onValueChange = { waiterSifre = it },
                        label = { Text("Şifre") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TealPrimary,
                            focusedLabelColor = TealPrimary,
                            unfocusedBorderColor = TextSecondary.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("dialog_waiter_password_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.addUser(
                            branchId = branchId,
                            ad = waiterAd,
                            kullaniciAdi = waiterUsername,
                            sifre = waiterSifre,
                            rol = "garson",
                            onSuccess = {
                                showAddDialog = false
                                Toast.makeText(context, "Garson başarıyla oluşturuldu.", Toast.LENGTH_SHORT).show()
                            },
                            onError = {
                                Toast.makeText(context, it, Toast.LENGTH_LONG).show()
                            }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TealPrimary, contentColor = DarkBg)
                ) {
                    Text("Oluştur", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("İptal", color = TextSecondary)
                }
            }
        )
    }
}

// --- 5.5 PERSONEL (STAFF) TAB & SHIFT HISTORY ---

enum class StaffDateFilter {
    TODAY, WEEK, MONTH, CUSTOM
}

fun getRangeStartTimestamp(filter: StaffDateFilter): Long {
    val cal = java.util.Calendar.getInstance()
    cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
    cal.set(java.util.Calendar.MINUTE, 0)
    cal.set(java.util.Calendar.SECOND, 0)
    cal.set(java.util.Calendar.MILLISECOND, 0)

    when (filter) {
        StaffDateFilter.TODAY -> {
            // Today 00:00
        }
        StaffDateFilter.WEEK -> {
            cal.firstDayOfWeek = java.util.Calendar.MONDAY
            cal.set(java.util.Calendar.DAY_OF_WEEK, java.util.Calendar.MONDAY)
            if (cal.timeInMillis > System.currentTimeMillis()) {
                cal.add(java.util.Calendar.DAY_OF_MONTH, -7)
            }
        }
        StaffDateFilter.MONTH -> {
            cal.set(java.util.Calendar.DAY_OF_MONTH, 1)
        }
        StaffDateFilter.CUSTOM -> {
            // Custom handled in composable
        }
    }
    return cal.timeInMillis
}

@Composable
fun PersonelTab(
    viewModel: AppViewModel,
    targetBranchId: String? = null,
    modifier: Modifier = Modifier
) {
    val defaultBranchId by viewModel.userBranchId.collectAsStateWithLifecycle()
    val branchId = targetBranchId ?: defaultBranchId
    var selectedGarson by remember { mutableStateOf<User?>(null) }

    Box(modifier = modifier.fillMaxSize().background(DarkBg)) {
        if (selectedGarson == null) {
            PersonelListContent(
                viewModel = viewModel,
                branchId = branchId,
                onGarsonClick = { garson -> selectedGarson = garson }
            )
        } else {
            GarsonShiftDetailContent(
                viewModel = viewModel,
                garson = selectedGarson!!,
                onBackClick = { selectedGarson = null }
            )
        }
    }
}

@Composable
fun PersonelListContent(
    viewModel: AppViewModel,
    branchId: String,
    onGarsonClick: (User) -> Unit
) {
    val branchActiveShifts by viewModel.branchActiveShifts.collectAsStateWithLifecycle()
    var waiters by remember { mutableStateOf<List<User>>(emptyList()) }

    DisposableEffect(branchId) {
        if (branchId.isNotEmpty()) {
            viewModel.startBranchActiveShiftsListener(branchId)
            val reg = viewModel.getWaitersForBranch(branchId) { loaded ->
                waiters = loaded
            }
            onDispose {
                reg.remove()
                viewModel.stopBranchActiveShiftsListener()
            }
        } else {
            onDispose {}
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Personel Canlı Durumu",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        if (waiters.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.PeopleOutline,
                        contentDescription = null,
                        tint = TextSecondary.copy(alpha = 0.5f),
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Şubede kayıtlı garson bulunamadı.",
                        color = TextSecondary,
                        fontSize = 14.sp
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(waiters, key = { it.uid }) { u ->
                    val activeShift = branchActiveShifts[u.uid]

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("personel_item_${u.uid}")
                            .clickable { onGarsonClick(u) },
                        colors = CardDefaults.cardColors(containerColor = DarkSurface),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Avatar Icon
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .background(TealPrimary.copy(alpha = 0.15f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    tint = TealPrimary,
                                    modifier = Modifier.size(24.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = u.ad.ifEmpty { u.kullaniciAdi },
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                                Text(
                                    text = "@${u.kullaniciAdi}",
                                    color = TextSecondary,
                                    fontSize = 12.sp
                                )
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            // Live Status Badge
                            val (badgeBg, badgeBorder, badgeText, badgeIcon) = when {
                                activeShift != null && activeShift.molada -> {
                                    Quadruple(
                                        StatusAmber.copy(alpha = 0.15f),
                                        StatusAmber,
                                        "🟠 Molada",
                                        StatusAmber
                                    )
                                }
                                activeShift != null && !activeShift.molada -> {
                                    Quadruple(
                                        StatusGreen.copy(alpha = 0.15f),
                                        StatusGreen,
                                        "🟢 Vardiyada",
                                        StatusGreen
                                    )
                                }
                                else -> {
                                    Quadruple(
                                        DarkBg,
                                        TextSecondary.copy(alpha = 0.3f),
                                        "⚫ Çevrimdışı",
                                        TextSecondary
                                    )
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .background(badgeBg, RoundedCornerShape(20.dp))
                                    .border(1.dp, badgeBorder, RoundedCornerShape(20.dp))
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = badgeText,
                                    color = badgeIcon,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)

@Composable
fun GarsonShiftDetailContent(
    viewModel: AppViewModel,
    garson: User,
    onBackClick: () -> Unit
) {
    var activeFilter by remember { mutableStateOf(StaffDateFilter.TODAY) }
    var showCustomDatePickerDialog by remember { mutableStateOf(false) }

    var customStartCal by remember {
        mutableStateOf(java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 0)
            set(java.util.Calendar.MINUTE, 0)
            set(java.util.Calendar.SECOND, 0)
            set(java.util.Calendar.MILLISECOND, 0)
        })
    }

    var customEndCal by remember {
        mutableStateOf(java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 23)
            set(java.util.Calendar.MINUTE, 59)
            set(java.util.Calendar.SECOND, 59)
            set(java.util.Calendar.MILLISECOND, 999)
        })
    }

    var shiftsWithBreaks by remember { mutableStateOf<List<ShiftWithBreaks>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    DisposableEffect(garson.uid) {
        val reg = viewModel.listenGarsonShiftsWithBreaks(garson.uid) { list ->
            shiftsWithBreaks = list
            isLoading = false
        }
        onDispose {
            reg.remove()
        }
    }

    val customRangeStr = remember(customStartCal, customEndCal) {
        val startFormatted = java.text.SimpleDateFormat("d MMM", java.util.Locale("tr")).format(customStartCal.time)
        val endFormatted = java.text.SimpleDateFormat("d MMM", java.util.Locale("tr")).format(customEndCal.time)
        "$startFormatted – $endFormatted"
    }

    val (rangeStartMs, rangeEndMs) = remember(activeFilter, customStartCal, customEndCal) {
        when (activeFilter) {
            StaffDateFilter.TODAY -> {
                val cal = java.util.Calendar.getInstance()
                cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
                cal.set(java.util.Calendar.MINUTE, 0)
                cal.set(java.util.Calendar.SECOND, 0)
                cal.set(java.util.Calendar.MILLISECOND, 0)
                Pair(cal.timeInMillis, Long.MAX_VALUE)
            }
            StaffDateFilter.WEEK -> {
                val cal = java.util.Calendar.getInstance()
                cal.firstDayOfWeek = java.util.Calendar.MONDAY
                cal.set(java.util.Calendar.DAY_OF_WEEK, java.util.Calendar.MONDAY)
                cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
                cal.set(java.util.Calendar.MINUTE, 0)
                cal.set(java.util.Calendar.SECOND, 0)
                cal.set(java.util.Calendar.MILLISECOND, 0)
                if (cal.timeInMillis > System.currentTimeMillis()) {
                    cal.add(java.util.Calendar.DAY_OF_MONTH, -7)
                }
                Pair(cal.timeInMillis, Long.MAX_VALUE)
            }
            StaffDateFilter.MONTH -> {
                val cal = java.util.Calendar.getInstance()
                cal.set(java.util.Calendar.DAY_OF_MONTH, 1)
                cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
                cal.set(java.util.Calendar.MINUTE, 0)
                cal.set(java.util.Calendar.SECOND, 0)
                cal.set(java.util.Calendar.MILLISECOND, 0)
                Pair(cal.timeInMillis, Long.MAX_VALUE)
            }
            StaffDateFilter.CUSTOM -> {
                Pair(customStartCal.timeInMillis, customEndCal.timeInMillis)
            }
        }
    }

    val filteredShifts = remember(shiftsWithBreaks, rangeStartMs, rangeEndMs) {
        shiftsWithBreaks.filter { item ->
            val startMs = item.shift.baslangic?.toDate()?.time ?: 0L
            startMs in rangeStartMs..rangeEndMs
        }
    }

    // Total summary calculations
    val totalGrossMs = filteredShifts.sumOf { item ->
        val end = item.shift.bitis?.toDate()?.time ?: System.currentTimeMillis()
        val start = item.shift.baslangic?.toDate()?.time ?: end
        (end - start).coerceAtLeast(0)
    }
    val totalGrossMins = totalGrossMs / (1000 * 60)
    val totalGrossHours = totalGrossMins / 60
    val totalGrossRemMins = totalGrossMins % 60
    val totalGrossStr = "${totalGrossHours}s ${totalGrossRemMins}dk"

    val totalBreakMs = filteredShifts.sumOf { item ->
        item.breaks.sumOf { mola ->
            val end = mola.bitis?.toDate()?.time ?: System.currentTimeMillis()
            val start = mola.baslangic?.toDate()?.time ?: end
            (end - start).coerceAtLeast(0)
        }
    }
    val totalBreakMins = totalBreakMs / (1000 * 60)
    val totalBreakHours = totalBreakMins / 60
    val totalBreakRemMins = totalBreakMins % 60
    val totalBreakStr = if (totalBreakHours > 0) "${totalBreakHours}s ${totalBreakRemMins}dk" else "${totalBreakRemMins}dk"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Back Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBackClick,
                modifier = Modifier.testTag("back_to_personel_list")
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Geri",
                    tint = TealPrimary
                )
            }
            Spacer(modifier = Modifier.width(4.dp))
            Column {
                Text(
                    text = garson.ad.ifEmpty { garson.kullaniciAdi },
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "@${garson.kullaniciAdi} — Vardiya Kayıtları",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 4 Filter Tabs (Bugün, Bu Hafta, Bu Ay, Tarih Seç)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            FilterTabButton(
                title = "Bugün",
                isSelected = activeFilter == StaffDateFilter.TODAY,
                onClick = { activeFilter = StaffDateFilter.TODAY },
                testTag = "filter_today",
                modifier = Modifier.weight(1f)
            )
            FilterTabButton(
                title = "Bu Hafta",
                isSelected = activeFilter == StaffDateFilter.WEEK,
                onClick = { activeFilter = StaffDateFilter.WEEK },
                testTag = "filter_week",
                modifier = Modifier.weight(1f)
            )
            FilterTabButton(
                title = "Bu Ay",
                isSelected = activeFilter == StaffDateFilter.MONTH,
                onClick = { activeFilter = StaffDateFilter.MONTH },
                testTag = "filter_month",
                modifier = Modifier.weight(1f)
            )
            FilterTabButton(
                title = if (activeFilter == StaffDateFilter.CUSTOM) customRangeStr else "Tarih Seç",
                isSelected = activeFilter == StaffDateFilter.CUSTOM,
                onClick = {
                    showCustomDatePickerDialog = true
                },
                testTag = "filter_custom",
                modifier = Modifier.weight(1.2f)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = TealPrimary)
            }
        } else if (filteredShifts.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Seçili tarih aralığında çalışma kaydı bulunamadı.",
                    color = TextSecondary,
                    fontSize = 14.sp
                )
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                items(filteredShifts, key = { it.shift.id }) { item ->
                    val shift = item.shift
                    val breaks = item.breaks

                    val dateStr = shift.baslangic?.toDate()?.let {
                        java.text.SimpleDateFormat("d MMMM yyyy, EEEE", java.util.Locale("tr")).format(it)
                    } ?: "-"

                    val girisStr = shift.baslangic?.toDate()?.let {
                        java.text.SimpleDateFormat("HH:mm", java.util.Locale("tr")).format(it)
                    } ?: ""

                    val cikisStr = if (shift.bitis != null) {
                        java.text.SimpleDateFormat("HH:mm", java.util.Locale("tr")).format(shift.bitis.toDate())
                    } else {
                        "devam ediyor"
                    }

                    val endMs = shift.bitis?.toDate()?.time ?: System.currentTimeMillis()
                    val startMs = shift.baslangic?.toDate()?.time ?: endMs
                    val grossMins = ((endMs - startMs) / (1000 * 60)).coerceAtLeast(0)
                    val grossStr = "${grossMins / 60}s ${grossMins % 60}dk"

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("shift_card_${shift.id}"),
                        colors = CardDefaults.cardColors(containerColor = DarkSurface),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp)
                        ) {
                            // Date header & Gross time badge
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = dateStr,
                                    color = TealPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )

                                Box(
                                    modifier = Modifier
                                        .background(TealPrimary.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = grossStr,
                                        color = TealAccent,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            // Giriş HH:mm – Çıkış HH:mm
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Schedule,
                                    contentDescription = null,
                                    tint = TextSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Giriş $girisStr – Çıkış $cikisStr",
                                    color = TextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }

                            // Breaks sub-items
                            if (breaks.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(8.dp))
                                HorizontalDivider(color = TextSecondary.copy(alpha = 0.2f))
                                Spacer(modifier = Modifier.height(6.dp))

                                Text(
                                    text = "Molalar:",
                                    color = TextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )

                                breaks.forEach { b ->
                                    val mGiris = b.baslangic?.toDate()?.let {
                                        java.text.SimpleDateFormat("HH:mm", java.util.Locale("tr")).format(it)
                                    } ?: ""
                                    val mCikis = if (b.bitis != null) {
                                        java.text.SimpleDateFormat("HH:mm", java.util.Locale("tr")).format(b.bitis.toDate())
                                    } else {
                                        "devam ediyor"
                                    }
                                    val mEndMs = b.bitis?.toDate()?.time ?: System.currentTimeMillis()
                                    val mStartMs = b.baslangic?.toDate()?.time ?: mEndMs
                                    val mMins = ((mEndMs - mStartMs) / (1000 * 60)).coerceAtLeast(0)

                                    Row(
                                        modifier = Modifier.padding(start = 8.dp, top = 2.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "• Mola $mGiris – $mCikis (${mMins}dk)",
                                            color = Color(0xFFFFC107),
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Bottom Summary Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 10.dp)
                .testTag("summary_card"),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = BorderStroke(1.dp, BorderColor),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp)
            ) {
                Text(
                    text = "Aralık Özet Bilgisi (${when (activeFilter) {
                        StaffDateFilter.TODAY -> "Bugün"
                        StaffDateFilter.WEEK -> "Bu Hafta"
                        StaffDateFilter.MONTH -> "Bu Ay"
                        StaffDateFilter.CUSTOM -> customRangeStr
                    }})",
                    color = TealPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Toplam Çalışma Süresi (Brüt):", color = TextSecondary, fontSize = 13.sp)
                    Text(text = totalGrossStr, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Toplam Mola Süresi:", color = TextSecondary, fontSize = 13.sp)
                    Text(text = totalBreakStr, color = StatusAmber, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    }

    if (showCustomDatePickerDialog) {
        CustomDateRangePickerDialog(
            initialStartCal = customStartCal,
            initialEndCal = customEndCal,
            onDismiss = { showCustomDatePickerDialog = false },
            onConfirm = { startCal, endCal ->
                customStartCal = startCal
                customEndCal = endCal
                activeFilter = StaffDateFilter.CUSTOM
                showCustomDatePickerDialog = false
            }
        )
    }
}

@Composable
fun CustomDateRangePickerDialog(
    initialStartCal: java.util.Calendar,
    initialEndCal: java.util.Calendar,
    onDismiss: () -> Unit,
    onConfirm: (java.util.Calendar, java.util.Calendar) -> Unit
) {
    val context = LocalContext.current
    var tempStartCal by remember {
        mutableStateOf(java.util.Calendar.getInstance().apply {
            timeInMillis = initialStartCal.timeInMillis
            set(java.util.Calendar.HOUR_OF_DAY, 0)
            set(java.util.Calendar.MINUTE, 0)
            set(java.util.Calendar.SECOND, 0)
            set(java.util.Calendar.MILLISECOND, 0)
        })
    }
    var tempEndCal by remember {
        mutableStateOf(java.util.Calendar.getInstance().apply {
            timeInMillis = initialEndCal.timeInMillis
            set(java.util.Calendar.HOUR_OF_DAY, 23)
            set(java.util.Calendar.MINUTE, 59)
            set(java.util.Calendar.SECOND, 59)
            set(java.util.Calendar.MILLISECOND, 999)
        })
    }

    val dateFormatter = remember { java.text.SimpleDateFormat("d MMMM yyyy", java.util.Locale("tr")) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        title = {
            Text(
                text = "Tarih Aralığı Seçin",
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Başlangıç Tarihi
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceSecondary),
                    border = BorderStroke(1.dp, BorderColor),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Başlangıç Tarihi", color = TextSecondary, fontSize = 12.sp)
                            Text(
                                text = dateFormatter.format(tempStartCal.time),
                                color = TealPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                        Button(
                            onClick = {
                                android.app.DatePickerDialog(
                                    context,
                                    { _, year, month, dayOfMonth ->
                                        val newCal = java.util.Calendar.getInstance().apply {
                                            set(year, month, dayOfMonth, 0, 0, 0)
                                            set(java.util.Calendar.MILLISECOND, 0)
                                        }
                                        tempStartCal = newCal
                                    },
                                    tempStartCal.get(java.util.Calendar.YEAR),
                                    tempStartCal.get(java.util.Calendar.MONTH),
                                    tempStartCal.get(java.util.Calendar.DAY_OF_MONTH)
                                ).show()
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = TealPrimary,
                                contentColor = DarkBg
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text("Seç", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Bitiş Tarihi
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceSecondary),
                    border = BorderStroke(1.dp, BorderColor),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Bitiş Tarihi", color = TextSecondary, fontSize = 12.sp)
                            Text(
                                text = dateFormatter.format(tempEndCal.time),
                                color = TealPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                        Button(
                            onClick = {
                                android.app.DatePickerDialog(
                                    context,
                                    { _, year, month, dayOfMonth ->
                                        val newCal = java.util.Calendar.getInstance().apply {
                                            set(year, month, dayOfMonth, 23, 59, 59)
                                            set(java.util.Calendar.MILLISECOND, 999)
                                        }
                                        tempEndCal = newCal
                                    },
                                    tempEndCal.get(java.util.Calendar.YEAR),
                                    tempEndCal.get(java.util.Calendar.MONTH),
                                    tempEndCal.get(java.util.Calendar.DAY_OF_MONTH)
                                ).show()
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = TealPrimary,
                                contentColor = DarkBg
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text("Seç", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val finalStart = if (tempStartCal.after(tempEndCal)) tempEndCal else tempStartCal
                    val finalEnd = if (tempStartCal.after(tempEndCal)) tempStartCal else tempStartCal
                    finalStart.set(java.util.Calendar.HOUR_OF_DAY, 0)
                    finalStart.set(java.util.Calendar.MINUTE, 0)
                    finalStart.set(java.util.Calendar.SECOND, 0)
                    finalStart.set(java.util.Calendar.MILLISECOND, 0)

                    finalEnd.set(java.util.Calendar.HOUR_OF_DAY, 23)
                    finalEnd.set(java.util.Calendar.MINUTE, 59)
                    finalEnd.set(java.util.Calendar.SECOND, 59)
                    finalEnd.set(java.util.Calendar.MILLISECOND, 999)

                    onConfirm(finalStart, finalEnd)
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = TealPrimary,
                    contentColor = DarkBg
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Uygula", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("İptal", color = TextSecondary)
            }
        }
    )
}

@Composable
fun FilterTabButton(
    title: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    testTag: String,
    modifier: Modifier = Modifier
) {
    Button(
        onClick = onClick,
        modifier = modifier.testTag(testTag),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isSelected) TealPrimary else DarkSurface,
            contentColor = if (isSelected) DarkBg else TextPrimary
        ),
        shape = RoundedCornerShape(8.dp),
        contentPadding = PaddingValues(horizontal = 2.dp, vertical = 6.dp)
    ) {
        Text(
            text = title,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

// --- 5.6 ANALYTICS TAB ---
@Composable
fun AnalyticsTab(
    viewModel: AppViewModel,
    siteUrl: String = WORDPRESS_BASE_URL
) {
    var activeFilter by remember { mutableStateOf(StaffDateFilter.TODAY) }
    var showCustomDatePickerDialog by remember { mutableStateOf(false) }

    val calls by viewModel.calls.collectAsStateWithLifecycle()
    val userBranchId by viewModel.userBranchId.collectAsStateWithLifecycle()

    LaunchedEffect(userBranchId) {
        if (userBranchId.isNotEmpty()) {
            viewModel.startCallsListener(userBranchId)
        }
    }

    var customStartCal by remember {
        mutableStateOf(java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 0)
            set(java.util.Calendar.MINUTE, 0)
            set(java.util.Calendar.SECOND, 0)
            set(java.util.Calendar.MILLISECOND, 0)
        })
    }

    var customEndCal by remember {
        mutableStateOf(java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 23)
            set(java.util.Calendar.MINUTE, 59)
            set(java.util.Calendar.SECOND, 59)
            set(java.util.Calendar.MILLISECOND, 999)
        })
    }

    val customRangeStr = remember(customStartCal, customEndCal) {
        val startFormatted = java.text.SimpleDateFormat("d MMM", java.util.Locale("tr")).format(customStartCal.time)
        val endFormatted = java.text.SimpleDateFormat("d MMM", java.util.Locale("tr")).format(customEndCal.time)
        "$startFormatted – $endFormatted"
    }

    val (baslangicStr, bitisStr) = remember(activeFilter, customStartCal, customEndCal) {
        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
        val todayCal = java.util.Calendar.getInstance()
        val todayStr = sdf.format(todayCal.time)

        when (activeFilter) {
            StaffDateFilter.TODAY -> {
                Pair(todayStr, todayStr)
            }
            StaffDateFilter.WEEK -> {
                val cal = java.util.Calendar.getInstance()
                cal.firstDayOfWeek = java.util.Calendar.MONDAY
                cal.set(java.util.Calendar.DAY_OF_WEEK, java.util.Calendar.MONDAY)
                if (cal.after(todayCal)) {
                    cal.add(java.util.Calendar.DAY_OF_MONTH, -7)
                }
                Pair(sdf.format(cal.time), todayStr)
            }
            StaffDateFilter.MONTH -> {
                val cal = java.util.Calendar.getInstance()
                cal.set(java.util.Calendar.DAY_OF_MONTH, 1)
                Pair(sdf.format(cal.time), todayStr)
            }
            StaffDateFilter.CUSTOM -> {
                Pair(sdf.format(customStartCal.time), sdf.format(customEndCal.time))
            }
        }
    }

    val (rangeStartMs, rangeEndMs) = remember(activeFilter, customStartCal, customEndCal) {
        when (activeFilter) {
            StaffDateFilter.TODAY -> {
                val cal = java.util.Calendar.getInstance()
                cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
                cal.set(java.util.Calendar.MINUTE, 0)
                cal.set(java.util.Calendar.SECOND, 0)
                cal.set(java.util.Calendar.MILLISECOND, 0)
                Pair(cal.timeInMillis, Long.MAX_VALUE)
            }
            StaffDateFilter.WEEK -> {
                val cal = java.util.Calendar.getInstance()
                cal.firstDayOfWeek = java.util.Calendar.MONDAY
                cal.set(java.util.Calendar.DAY_OF_WEEK, java.util.Calendar.MONDAY)
                cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
                cal.set(java.util.Calendar.MINUTE, 0)
                cal.set(java.util.Calendar.SECOND, 0)
                cal.set(java.util.Calendar.MILLISECOND, 0)
                if (cal.timeInMillis > System.currentTimeMillis()) {
                    cal.add(java.util.Calendar.DAY_OF_MONTH, -7)
                }
                Pair(cal.timeInMillis, Long.MAX_VALUE)
            }
            StaffDateFilter.MONTH -> {
                val cal = java.util.Calendar.getInstance()
                cal.set(java.util.Calendar.DAY_OF_MONTH, 1)
                cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
                cal.set(java.util.Calendar.MINUTE, 0)
                cal.set(java.util.Calendar.SECOND, 0)
                cal.set(java.util.Calendar.MILLISECOND, 0)
                Pair(cal.timeInMillis, Long.MAX_VALUE)
            }
            StaffDateFilter.CUSTOM -> {
                Pair(customStartCal.timeInMillis, customEndCal.timeInMillis)
            }
        }
    }

    val tableSiparisCalls = remember(calls, rangeStartMs, rangeEndMs, userBranchId) {
        calls.filter { call ->
            (userBranchId.isEmpty() || call.branchId == userBranchId) &&
            call.tip == "siparis" && run {
                val ts = call.createdAt?.toDate()?.time ?: 0L
                ts in rangeStartMs..rangeEndMs
            }
        }
    }

    val groupedTableOrders = remember(tableSiparisCalls) {
        tableSiparisCalls.groupBy { it.masaNo }
            .mapValues { entry -> entry.value.sortedByDescending { it.createdAt?.toDate()?.time ?: 0L } }
            .toList()
            .sortedBy { (masaNo, _) -> masaNo.toIntOrNull() ?: Int.MAX_VALUE }
    }

    var analyticsData by remember { mutableStateOf<AnalyticsResponse?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    fun loadAnalytics() {
        isLoading = true
        errorMessage = null
        viewModel.fetchAnalytics(
            baslangic = baslangicStr,
            bitis = bitisStr,
            siteUrl = siteUrl
        ) { data, err ->
            isLoading = false
            if (err != null) {
                errorMessage = err
            } else {
                analyticsData = data
            }
        }
    }

    LaunchedEffect(baslangicStr, bitisStr, siteUrl) {
        loadAnalytics()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        // Top Header with Refresh Button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Analiz Özeti",
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
            IconButton(
                onClick = { loadAnalytics() },
                enabled = !isLoading,
                modifier = Modifier.testTag("refresh_analytics_button")
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        color = TealPrimary,
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.dp
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Yenile",
                        tint = TealPrimary
                    )
                }
            }
        }

        // Filter Tabs (Bugün, Bu Hafta, Bu Ay, Tarih Seç)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            FilterTabButton(
                title = "Bugün",
                isSelected = activeFilter == StaffDateFilter.TODAY,
                onClick = { activeFilter = StaffDateFilter.TODAY },
                testTag = "analytics_filter_today",
                modifier = Modifier.weight(1f)
            )
            FilterTabButton(
                title = "Bu Hafta",
                isSelected = activeFilter == StaffDateFilter.WEEK,
                onClick = { activeFilter = StaffDateFilter.WEEK },
                testTag = "analytics_filter_week",
                modifier = Modifier.weight(1f)
            )
            FilterTabButton(
                title = "Bu Ay",
                isSelected = activeFilter == StaffDateFilter.MONTH,
                onClick = { activeFilter = StaffDateFilter.MONTH },
                testTag = "analytics_filter_month",
                modifier = Modifier.weight(1f)
            )
            FilterTabButton(
                title = if (activeFilter == StaffDateFilter.CUSTOM) customRangeStr else "Tarih Seç",
                isSelected = activeFilter == StaffDateFilter.CUSTOM,
                onClick = { showCustomDatePickerDialog = true },
                testTag = "analytics_filter_custom",
                modifier = Modifier.weight(1.2f)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = TealPrimary)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Analiz verileri yükleniyor...", color = TextSecondary, fontSize = 14.sp)
                }
            }
        } else if (errorMessage != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.ErrorOutline,
                        contentDescription = null,
                        tint = ErrorColor,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = errorMessage ?: "Bir hata oluştu",
                        color = TextPrimary,
                        textAlign = TextAlign.Center,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = { loadAnalytics() },
                        colors = ButtonDefaults.buttonColors(containerColor = TealPrimary, contentColor = DarkBg)
                    ) {
                        Text("Tekrar Dene", fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            val data = analyticsData
            val hasData = data != null && (
                data.toplamGoruntulenme > 0 ||
                data.tekilZiyaretci > 0 ||
                data.toplamTiklama > 0 ||
                data.enCok.isNotEmpty() ||
                data.enAz.isNotEmpty() ||
                data.masalar.isNotEmpty()
            )

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                // Masa Bazlı Siparişler
                item {
                    AnalyticsTableOrdersSection(groupedOrders = groupedTableOrders)
                }

                if (hasData) {
                    // Top 3 Summary Cards
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            AnalyticsSummaryCard(
                                title = "Görüntülenme",
                                value = data!!.toplamGoruntulenme.toString(),
                                icon = Icons.Default.Visibility,
                                modifier = Modifier.weight(1f)
                            )
                            AnalyticsSummaryCard(
                                title = "Tekil Ziyaretçi",
                                value = data.tekilZiyaretci.toString(),
                                icon = Icons.Default.Person,
                                modifier = Modifier.weight(1f)
                            )
                            AnalyticsSummaryCard(
                                title = "Ürün Tıklaması",
                                value = data.toplamTiklama.toString(),
                                icon = Icons.Default.TouchApp,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    // En Çok İlgi Gören Ürünler
                    if (data!!.enCok.isNotEmpty()) {
                        item {
                            AnalyticsProductListSection(
                                title = "En Çok İlgi Gören Ürünler",
                                icon = Icons.Default.TrendingUp,
                                items = data.enCok.take(10)
                            )
                        }
                    }

                    // En Az İlgi Gören Ürünler
                    if (data.enAz.isNotEmpty()) {
                        item {
                            AnalyticsProductListSection(
                                title = "En Az İlgi Gören Ürünler",
                                icon = Icons.Default.TrendingDown,
                                items = data.enAz.take(10)
                            )
                        }
                    }

                    // Masa Bazlı Trafik
                    if (data.masalar.isNotEmpty()) {
                        item {
                            AnalyticsTableListSection(
                                title = "Masa Bazlı Trafik",
                                icon = Icons.Default.TableRestaurant,
                                items = data.masalar
                            )
                        }
                    }
                }
            }
        }
    }

    if (showCustomDatePickerDialog) {
        CustomDateRangePickerDialog(
            initialStartCal = customStartCal,
            initialEndCal = customEndCal,
            onDismiss = { showCustomDatePickerDialog = false },
            onConfirm = { startCal, endCal ->
                customStartCal = startCal
                customEndCal = endCal
                activeFilter = StaffDateFilter.CUSTOM
                showCustomDatePickerDialog = false
            }
        )
    }
}

@Composable
fun AnalyticsTableOrdersSection(
    groupedOrders: List<Pair<String, List<Call>>>
) {
    var expandedMasaNos by remember { mutableStateOf(setOf<String>()) }
    val dateTimeFormat = remember { java.text.SimpleDateFormat("dd MMM HH:mm", java.util.Locale("tr")) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("analytics_table_orders_section"),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, Color(0xFF232B38))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(TealPrimary.copy(alpha = 0.15f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Restaurant,
                        contentDescription = null,
                        tint = TealPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Masa Bazlı Siparişler",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    val totalSiparis = groupedOrders.sumOf { it.second.size }
                    Text(
                        text = "${groupedOrders.size} masa · toplam $totalSiparis sipariş",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (groupedOrders.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Bu tarih aralığında sipariş bulunamadı.",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                }
            } else {
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    groupedOrders.forEach { (masaNo, orders) ->
                        val isExpanded = expandedMasaNos.contains(masaNo)

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    expandedMasaNos = if (isExpanded) {
                                        expandedMasaNos - masaNo
                                    } else {
                                        expandedMasaNos + masaNo
                                    }
                                }
                                .testTag("table_orders_row_$masaNo"),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF151821)),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, if (isExpanded) TealPrimary.copy(alpha = 0.5f) else Color(0xFF232B38))
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${FormatUtils.formatMasaTitle(masaNo)} — ${orders.size} sipariş",
                                        color = TextPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )

                                    Icon(
                                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                        contentDescription = if (isExpanded) "Daralt" else "Genişlet",
                                        tint = TealPrimary
                                    )
                                }

                                if (isExpanded) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    HorizontalDivider(color = Color(0xFF232B38), thickness = 1.dp)
                                    Spacer(modifier = Modifier.height(12.dp))

                                    Column(
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        orders.forEach { call ->
                                            val isApproved = call.durum == "onaylandi"
                                            val isCancelled = call.durum == "iptal"

                                            val statusBg = when {
                                                isApproved -> Color(0xFF10B981).copy(alpha = 0.15f)
                                                isCancelled -> Color(0xFFEF5350).copy(alpha = 0.15f)
                                                else -> TealPrimary.copy(alpha = 0.15f)
                                            }
                                            val statusColor = when {
                                                isApproved -> Color(0xFF34D399)
                                                isCancelled -> Color(0xFFEF5350)
                                                else -> TealAccent
                                            }
                                            val statusText = when {
                                                isApproved -> if (call.onaylayanAd.isNotEmpty()) "Onaylandı (${call.onaylayanAd})" else "Onaylandı"
                                                isCancelled -> if (call.iptalEdenAd.isNotEmpty()) "İptal (${call.iptalEdenAd})" else "İptal"
                                                else -> "Bekliyor"
                                            }

                                            val callDate = call.createdAt?.toDate()
                                            val dateStr = if (callDate != null) dateTimeFormat.format(callDate) else "-"

                                            Card(
                                                modifier = Modifier.fillMaxWidth(),
                                                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                                                shape = RoundedCornerShape(8.dp),
                                                border = BorderStroke(1.dp, Color(0xFF232B38))
                                            ) {
                                                Column(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(10.dp)
                                                ) {
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Box(
                                                            modifier = Modifier
                                                                .background(statusBg, RoundedCornerShape(4.dp))
                                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                                        ) {
                                                            Text(
                                                                text = statusText,
                                                                color = statusColor,
                                                                fontSize = 11.sp,
                                                                fontWeight = FontWeight.Bold
                                                            )
                                                        }

                                                        Text(
                                                            text = dateStr,
                                                            color = TextSecondary,
                                                            fontSize = 11.sp
                                                        )
                                                    }

                                                    if (isCancelled && call.iptalNedeni.isNotEmpty()) {
                                                        Spacer(modifier = Modifier.height(4.dp))
                                                        Text(
                                                            text = "İptal Nedeni: ${call.iptalNedeni}",
                                                            color = Color(0xFFEF9A9A),
                                                            fontSize = 11.sp,
                                                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                                                        )
                                                    }

                                                    Spacer(modifier = Modifier.height(8.dp))

                                                    // Items
                                                    Column(
                                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                                    ) {
                                                        call.items.forEach { item ->
                                                            Column(modifier = Modifier.fillMaxWidth()) {
                                                                Text(
                                                                    text = "${item.adet}x ${item.urunAdi}",
                                                                    color = TextPrimary,
                                                                    fontSize = 13.sp,
                                                                    fontWeight = FontWeight.Medium
                                                                )
                                                                val noteToShow = item.notTr?.takeIf { it.isNotBlank() } ?: item.notOrijinal
                                                                if (!noteToShow.isNullOrBlank()) {
                                                                    Text(
                                                                        text = "Not: $noteToShow",
                                                                        color = TealAccent,
                                                                        fontSize = 11.sp,
                                                                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                                                                    )
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AnalyticsSummaryCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, Color(0xFF232B38))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = TealPrimary,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = value,
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                maxLines = 1
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = title,
                color = TextSecondary,
                fontSize = 11.sp,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun AnalyticsProductListSection(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    items: List<AnalyticsProductItem>
) {
    val maxClicks = remember(items) { (items.maxOfOrNull { it.tiklamaAdedi } ?: 1).coerceAtLeast(1) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, Color(0xFF232B38))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = TealPrimary, modifier = Modifier.size(20.dp))
                Text(
                    text = title,
                    color = TealPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            items.forEachIndexed { index, item ->
                if (index > 0) {
                    HorizontalDivider(
                        color = Color(0xFF232B38),
                        thickness = 1.dp,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                }

                val progress = (item.tiklamaAdedi.toFloat() / maxClicks.toFloat()).coerceIn(0.05f, 1f)

                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.urunAd.ifEmpty { "İsimsiz Ürün" },
                                color = TextPrimary,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (item.kategori.isNotEmpty()) {
                                Text(
                                    text = item.kategori,
                                    color = TextSecondary,
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        Text(
                            text = "${item.tiklamaAdedi} tık",
                            color = TealAccent,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(start = 8.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Soft Golden Progress Bar
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(Color(0xFF151821))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(progress)
                                .clip(RoundedCornerShape(3.dp))
                                .background(TealPrimary)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AnalyticsTableListSection(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    items: List<AnalyticsTableItem>
) {
    val maxViews = remember(items) { (items.maxOfOrNull { it.goruntulenmeAdedi } ?: 1).coerceAtLeast(1) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, Color(0xFF232B38))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = TealPrimary, modifier = Modifier.size(20.dp))
                Text(
                    text = title,
                    color = TealPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            items.forEachIndexed { index, item ->
                if (index > 0) {
                    HorizontalDivider(
                        color = Color(0xFF232B38),
                        thickness = 1.dp,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                }

                val progress = (item.goruntulenmeAdedi.toFloat() / maxViews.toFloat()).coerceIn(0.05f, 1f)

                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = item.masaAd.ifEmpty { "İsimsiz Masa" },
                            color = TextPrimary,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = "${item.goruntulenmeAdedi} açılış",
                            color = TealAccent,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(start = 8.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Soft Golden Progress Bar
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(Color(0xFF151821))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(progress)
                                .clip(RoundedCornerShape(3.dp))
                                .background(TealPrimary)
                        )
                    }
                }
            }
        }
    }
}

